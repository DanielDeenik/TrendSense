import express from 'express';
import cors from 'cors';
import path from 'path';
import dotenv from 'dotenv';
import routes from './routes';
import { storage } from './storage';

// Load environment variables
dotenv.config();

// Set up Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API routes
app.use(routes);

// Serve the frontend static assets in production
if (process.env.NODE_ENV === 'production') {
  const clientBuildPath = path.join(__dirname, '../client/build');
  app.use(express.static(clientBuildPath));
  
  // Fallback to index.html for client-side routing
  app.get('*', (req, res) => {
    res.sendFile(path.join(clientBuildPath, 'index.html'));
  });
}

// Sample data for development
async function seedSampleData() {
  if (process.env.NODE_ENV !== 'production') {
    try {
      // Check if we already have any funds
      const existingFunds = await storage.getFunds();
      
      if (existingFunds.length === 0) {
        console.log('Seeding sample data...');
        
        // Create a sample fund
        const fund = await storage.createFund({
          name: 'Sustainability Ventures',
          description: 'Venture capital fund focused on sustainability investments'
        });
        
        // Create sample companies
        const company1 = await storage.createCompany({
          fundId: fund.id,
          name: 'EcoTech Solutions',
          sector: 'Clean Energy',
          description: 'Renewable energy technology provider',
          isPublic: true
        });
        
        const company2 = await storage.createCompany({
          fundId: fund.id,
          name: 'GreenWater',
          sector: 'Water Management',
          description: 'Advanced water conservation systems',
          isPublic: false
        });
        
        // Create sample metrics
        await storage.createMetric({
          companyId: company1.id,
          name: 'Carbon Intensity',
          category: 'emissions',
          value: 12.4,
          unit: 'tCO2e/M$',
          isAnonymized: false
        });
        
        await storage.createMetric({
          companyId: company1.id,
          name: 'ESG Score',
          category: 'governance',
          value: 73.8,
          unit: 'points',
          isAnonymized: false
        });
        
        await storage.createMetric({
          companyId: company1.id,
          name: 'Renewable Energy',
          category: 'energy',
          value: 38,
          unit: '%',
          isAnonymized: false
        });
        
        await storage.createMetric({
          companyId: company2.id,
          name: 'Water Intensity',
          category: 'water',
          value: 2.3,
          unit: 'kL/M$',
          isAnonymized: false
        });
        
        // Create a sample pattern
        const pattern = await storage.createPattern({
          name: 'Renewable Energy Adoption Trend',
          description: 'Companies investing in renewable energy show improved ESG scores',
          category: 'energy',
          detectionMethod: 'correlation-analysis',
          confidence: 0.85,
          dataPoints: [
            { company: 'EcoTech Solutions', metric: 'Renewable Energy', value: 38 },
            { company: 'EcoTech Solutions', metric: 'ESG Score', value: 73.8 }
          ],
          aiExplanation: 'This pattern indicates a positive correlation between renewable energy adoption and ESG performance.'
        });
        
        // Create a sample story
        await storage.createStory({
          title: 'Renewable Energy Drives ESG Performance',
          content: 'Companies that invest in renewable energy sources consistently show better ESG scores and lower carbon intensity.',
          patternId: pattern.id,
          visualizationType: 'line-chart',
          visualizationData: {
            labels: ['Q1', 'Q2', 'Q3', 'Q4'],
            datasets: [
              {
                label: 'Renewable Energy',
                data: [32, 35, 37, 38]
              },
              {
                label: 'ESG Score',
                data: [68, 70, 72, 73.8]
              }
            ]
          }
        });
        
        console.log('Sample data seeded successfully');
      } else {
        console.log('Skipping sample data seeding - data already exists');
      }
    } catch (error) {
      console.error('Error seeding sample data:', error);
    }
  }
}

// Start the server
app.listen(port, '0.0.0.0', async () => {
  console.log(`Server running on port ${port}`);
  
  // Seed sample data
  await seedSampleData();
});

export default app;