import { MongoClient, Db, Collection } from 'mongodb';
import 'dotenv/config';

// MongoDB connection URL from environment variables
const getMongoDbUrl = (): string => {
  return process.env.MONGODB_URI || 'mongodb://localhost:27017';
};

// Database Name
const DB_NAME = process.env.MONGODB_DB_NAME || 'trendsense_vc';

// Collections
const COLLECTIONS = {
  DOCUMENTS: 'documents',
  PATTERNS: 'patterns',
  ANALYSIS: 'analysis',
  VECTOR_EMBEDDINGS: 'vector_embeddings'
};

// MongoDB client instance
let client: MongoClient | null = null;
let db: Db | null = null;

/**
 * Connect to MongoDB
 */
export const connectToMongoDB = async (): Promise<boolean> => {
  try {
    if (!client) {
      client = new MongoClient(getMongoDbUrl());
      await client.connect();
      console.log('Successfully connected to MongoDB');
      
      db = client.db(DB_NAME);
      
      // Create indices for better query performance
      const documentsCollection = db.collection(COLLECTIONS.DOCUMENTS);
      await documentsCollection.createIndex({ company_id: 1 });
      await documentsCollection.createIndex({ type: 1 });
      await documentsCollection.createIndex({ created_at: -1 });
      
      const patternsCollection = db.collection(COLLECTIONS.PATTERNS);
      await patternsCollection.createIndex({ type: 1 });
      await patternsCollection.createIndex({ is_federated: 1 });
      await patternsCollection.createIndex({ confidence: -1 });
      
      const vectorEmbeddingsCollection = db.collection(COLLECTIONS.VECTOR_EMBEDDINGS);
      await vectorEmbeddingsCollection.createIndex({ document_id: 1 });
      
      return true;
    }
    
    return !!db;
  } catch (error) {
    console.error('MongoDB connection error:', error);
    return false;
  }
};

/**
 * Close MongoDB connection
 */
export const closeMongoDBConnection = async (): Promise<void> => {
  if (client) {
    await client.close();
    client = null;
    db = null;
    console.log('MongoDB connection closed');
  }
};

/**
 * Get a MongoDB collection
 */
export const getCollection = <T = any>(collectionName: string): Collection<T> | null => {
  if (!db) {
    console.error('MongoDB not connected. Call connectToMongoDB first.');
    return null;
  }
  
  return db.collection<T>(collectionName);
};

/**
 * Document Storage Interface
 */
export interface DocumentStorage {
  saveDocument(document: any): Promise<string>;
  getDocumentById(id: string): Promise<any | null>;
  getDocumentsByCompanyId(companyId: number): Promise<any[]>;
  updateDocument(id: string, updates: any): Promise<boolean>;
  deleteDocument(id: string): Promise<boolean>;
}

/**
 * MongoDB Document Storage Implementation
 */
export class MongoDBDocumentStorage implements DocumentStorage {
  private collection: Collection | null;
  
  constructor() {
    this.collection = getCollection(COLLECTIONS.DOCUMENTS);
  }
  
  async saveDocument(document: any): Promise<string> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const timestamp = new Date();
    const docToInsert = {
      ...document,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    const result = await this.collection.insertOne(docToInsert);
    return result.insertedId.toString();
  }
  
  async getDocumentById(id: string): Promise<any | null> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    return await this.collection.findOne({ _id: id });
  }
  
  async getDocumentsByCompanyId(companyId: number): Promise<any[]> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    return await this.collection.find({ company_id: companyId }).sort({ created_at: -1 }).toArray();
  }
  
  async updateDocument(id: string, updates: any): Promise<boolean> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const result = await this.collection.updateOne(
      { _id: id },
      { 
        $set: { 
          ...updates,
          updated_at: new Date()
        } 
      }
    );
    
    return result.modifiedCount > 0;
  }
  
  async deleteDocument(id: string): Promise<boolean> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const result = await this.collection.deleteOne({ _id: id });
    return result.deletedCount > 0;
  }
}

/**
 * Pattern Storage Interface
 */
export interface PatternStorage {
  savePattern(pattern: any): Promise<string>;
  getPatternById(id: string): Promise<any | null>;
  getPatterns(type?: string, isFederated?: boolean): Promise<any[]>;
  updatePattern(id: string, updates: any): Promise<boolean>;
  deletePattern(id: string): Promise<boolean>;
  getFederatedPatterns(): Promise<any[]>;
}

/**
 * MongoDB Pattern Storage Implementation
 */
export class MongoDBPatternStorage implements PatternStorage {
  private collection: Collection | null;
  
  constructor() {
    this.collection = getCollection(COLLECTIONS.PATTERNS);
  }
  
  async savePattern(pattern: any): Promise<string> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const timestamp = new Date();
    const patternToInsert = {
      ...pattern,
      created_at: timestamp,
      updated_at: timestamp
    };
    
    const result = await this.collection.insertOne(patternToInsert);
    return result.insertedId.toString();
  }
  
  async getPatternById(id: string): Promise<any | null> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    return await this.collection.findOne({ _id: id });
  }
  
  async getPatterns(type?: string, isFederated?: boolean): Promise<any[]> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const query: any = {};
    
    if (type) {
      query.type = type;
    }
    
    if (isFederated !== undefined) {
      query.is_federated = isFederated;
    }
    
    return await this.collection.find(query).sort({ confidence: -1 }).toArray();
  }
  
  async updatePattern(id: string, updates: any): Promise<boolean> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const result = await this.collection.updateOne(
      { _id: id },
      { 
        $set: { 
          ...updates,
          updated_at: new Date()
        } 
      }
    );
    
    return result.modifiedCount > 0;
  }
  
  async deletePattern(id: string): Promise<boolean> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    const result = await this.collection.deleteOne({ _id: id });
    return result.deletedCount > 0;
  }
  
  async getFederatedPatterns(): Promise<any[]> {
    if (!this.collection) {
      throw new Error('MongoDB collection not available');
    }
    
    return await this.collection.find({ is_federated: true })
      .sort({ confidence: -1 })
      .toArray();
  }
}

// Create singleton instances
export const documentStorage = new MongoDBDocumentStorage();
export const patternStorage = new MongoDBPatternStorage();

// Handle process termination signals
process.on('SIGINT', async () => {
  console.log('Received SIGINT. Closing MongoDB connections...');
  await closeMongoDBConnection();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('Received SIGTERM. Closing MongoDB connections...');
  await closeMongoDBConnection();
  process.exit(0);
});