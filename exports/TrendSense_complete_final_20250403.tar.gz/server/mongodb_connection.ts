/**
 * MongoDB Connection Module
 * 
 * This module provides MongoDB connection management and utility functions
 * for the TrendSense VC Platform.
 */

// MongoDB connection management
// Note: This file requires the mongodb package to be installed
// npm install mongodb

import { MongoClient, ObjectId, Db, Collection } from 'mongodb';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// MongoDB connection URI (prefer MONGODB_URI for Atlas connections)
const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://localhost:27017';
const DB_NAME = process.env.MONGO_DB_NAME || 'trendsense_vc';

// Connection options
const options = {
  serverSelectionTimeoutMS: 5000,
  connectTimeoutMS: 10000,
};

// MongoDB client (singleton)
let client: MongoClient | null = null;
let db: Db | null = null;

/**
 * Connect to MongoDB
 * @returns {Promise<Db>} MongoDB database connection
 */
export async function connectToMongoDB(): Promise<Db> {
  if (db) {
    return db;
  }

  try {
    console.log(`Connecting to MongoDB at ${MONGODB_URI}...`);
    client = new MongoClient(MONGODB_URI, options);
    await client.connect();
    console.log('Connected to MongoDB successfully');
    
    db = client.db(DB_NAME);
    return db;
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    throw new Error(`MongoDB connection failed: ${error}`);
  }
}

/**
 * Get MongoDB database connection (creates connection if not exists)
 * @returns {Promise<Db>} MongoDB database connection
 */
export async function getMongoDb(): Promise<Db> {
  if (!db) {
    return connectToMongoDB();
  }
  return db;
}

/**
 * Get MongoDB collection
 * @param {string} collectionName - Name of the collection
 * @returns {Promise<Collection>} MongoDB collection
 */
export async function getCollection(collectionName: string): Promise<Collection> {
  const db = await getMongoDb();
  return db.collection(collectionName);
}

/**
 * Close MongoDB connection
 */
export async function closeMongoDbConnection(): Promise<void> {
  if (client) {
    await client.close();
    client = null;
    db = null;
    console.log('MongoDB connection closed');
  }
}

/**
 * Convert string to ObjectId
 * @param {string} id - String ID to convert
 * @returns {ObjectId} MongoDB ObjectId
 */
export function toObjectId(id: string): ObjectId {
  try {
    return new ObjectId(id);
  } catch (error) {
    throw new Error(`Invalid ObjectId: ${id}`);
  }
}

/**
 * Serialize MongoDB document (convert ObjectId to string)
 * @param {any} doc - MongoDB document to serialize
 * @returns {any} Serialized document
 */
export function serializeMongoDocument(doc: any): any {
  if (!doc) return null;
  
  // Create a copy of the document
  const serialized = { ...doc };
  
  // Convert _id to string if it exists
  if (serialized._id && typeof serialized._id !== 'string') {
    serialized._id = serialized._id.toString();
  }
  
  return serialized;
}

/**
 * Serialize MongoDB documents (convert ObjectIds to strings)
 * @param {any[]} docs - MongoDB documents to serialize
 * @returns {any[]} Serialized documents
 */
export function serializeMongoDocuments(docs: any[]): any[] {
  if (!docs) return [];
  return docs.map(serializeMongoDocument);
}

/**
 * Check if MongoDB connection is active
 * @returns {Promise<boolean>} True if connected, false otherwise
 */
export async function isMongoDbConnected(): Promise<boolean> {
  if (!client) {
    return false;
  }
  
  try {
    // Ping the database to check if connection is alive
    await client.db().admin().ping();
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Initialize MongoDB collections and indexes
 * This function creates collections and sets up indexes if they don't exist
 * @returns {Promise<boolean>} True if successful, false otherwise
 */
export async function initializeMongoDb(): Promise<boolean> {
  try {
    const db = await getMongoDb();
    
    // Collection definitions with indexes
    const collections = [
      {
        name: 'documents',
        indexes: [
          { key: { title: 'text', content: 'text', tags: 'text' } },
          { key: { company_id: 1 } },
          { key: { fund_id: 1 } },
          { key: { created_at: 1 } }
        ]
      },
      {
        name: 'patterns',
        indexes: [
          { key: { name: 'text', description: 'text' } },
          { key: { sector: 1 } },
          { key: { confidence: 1 } },
          { key: { created_at: 1 } }
        ]
      },
      {
        name: 'stories',
        indexes: [
          { key: { title: 'text', content: 'text' } },
          { key: { company_id: 1 } },
          { key: { views: 1 } },
          { key: { created_at: 1 } }
        ]
      },
      {
        name: 'theses',
        indexes: [
          { key: { name: 'text', content: 'text' } },
          { key: { fund_id: 1 } },
          { key: { sector: 1 } },
          { key: { created_at: 1 } }
        ]
      }
    ];
    
    // Create collections and indexes
    for (const collection of collections) {
      // Get the collection list
      const collectionList = await db.listCollections().toArray();
      const collectionNames = collectionList.map(c => c.name);
      
      // Create collection if it doesn't exist
      if (!collectionNames.includes(collection.name)) {
        await db.createCollection(collection.name);
        console.log(`Created collection: ${collection.name}`);
      }
      
      // Create indexes
      const coll = db.collection(collection.name);
      for (const index of collection.indexes) {
        const indexName = Object.keys(index.key).join('_');
        await coll.createIndex(index.key, { name: indexName });
        console.log(`Created index: ${indexName} on ${collection.name}`);
      }
    }
    
    console.log('MongoDB initialization completed successfully');
    return true;
  } catch (error) {
    console.error('Failed to initialize MongoDB:', error);
    return false;
  }
}