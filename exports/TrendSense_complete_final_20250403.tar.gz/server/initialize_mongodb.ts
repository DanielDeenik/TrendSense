/**
 * MongoDB Initialization Module
 */

import { 
  connectToMongoDB, 
  closeMongoDbConnection, 
  getCollection, 
  initializeMongoDb 
} from './mongodb_connection';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

/**
 * Initialize MongoDB with collections and indexes
 * @returns {Promise<boolean>} True if successful, false otherwise
 */
export async function initializeMongoDB(): Promise<boolean> {
  console.log('Initializing MongoDB...');
  
  try {
    // Initialize MongoDB collections and indexes
    const initialized = await initializeMongoDb();
    
    if (initialized) {
      console.log('MongoDB initialization completed successfully');
      return true;
    } else {
      console.error('MongoDB initialization failed');
      return false;
    }
  } catch (error) {
    console.error('Error initializing MongoDB:', error);
    return false;
  }
}

/**
 * Create test data for development
 * @returns {Promise<boolean>} True if successful, false otherwise
 */
export async function createTestData(): Promise<boolean> {
  console.log('Creating test data...');
  
  try {
    // Document collection test data
    const documentsCollection = await getCollection('documents');
    
    // Check if documents collection already has data
    const documentCount = await documentsCollection.countDocuments({});
    if (documentCount === 0) {
      console.log('Creating test documents...');
      
      // Insert sample documents
      await documentsCollection.insertMany([
        {
          title: "2023 Sustainability Report",
          content: "This report outlines our company's commitment to sustainability...",
          company_id: 1,
          fund_id: 1,
          tags: ["sustainability", "ESG", "annual-report"],
          created_at: new Date(),
          metadata: {
            author: "Sustainability Team",
            pages: 42,
            format: "PDF"
          }
        },
        {
          title: "Carbon Reduction Strategy",
          content: "Our strategy for reducing carbon emissions across operations...",
          company_id: 2,
          fund_id: 1,
          tags: ["carbon", "emissions", "strategy"],
          created_at: new Date(),
          metadata: {
            author: "Climate Action Team",
            pages: 28,
            format: "PDF"
          }
        }
      ]);
      
      console.log('Test documents created successfully');
    } else {
      console.log('Documents collection already has data, skipping...');
    }
    
    // Pattern collection test data
    const patternsCollection = await getCollection('patterns');
    
    // Check if patterns collection already has data
    const patternCount = await patternsCollection.countDocuments({});
    if (patternCount === 0) {
      console.log('Creating test patterns...');
      
      // Insert sample patterns
      await patternsCollection.insertMany([
        {
          name: "Early Sustainability Adoption",
          description: "Companies that implement sustainability initiatives early show better long-term profitability",
          sector: "Technology",
          confidence: 0.87,
          supporting_data: {
            company_count: 12,
            avg_roi: 18.5,
            timeframe: "3 years"
          },
          created_at: new Date()
        },
        {
          name: "Carbon Trading Advantage",
          description: "Companies participating in carbon markets outperform sector peers",
          sector: "Energy",
          confidence: 0.79,
          supporting_data: {
            company_count: 8,
            avg_roi: 12.3,
            timeframe: "2 years"
          },
          created_at: new Date()
        }
      ]);
      
      console.log('Test patterns created successfully');
    } else {
      console.log('Patterns collection already has data, skipping...');
    }
    
    // Stories collection test data
    const storiesCollection = await getCollection('stories');
    
    // Check if stories collection already has data
    const storyCount = await storiesCollection.countDocuments({});
    if (storyCount === 0) {
      console.log('Creating test stories...');
      
      // Insert sample stories
      await storiesCollection.insertMany([
        {
          title: "From Carbon Intensive to Climate Positive",
          content: "The journey of transforming a manufacturing company's operations...",
          company_id: 3,
          published: true,
          metrics: {
            carbon_reduced: 12500,
            water_saved: 1800000,
            renewable_energy: 78
          },
          engagement_metrics: {
            views: 156,
            likes: 23,
            shares: 12,
            comments: 8
          },
          created_at: new Date()
        },
        {
          title: "Creating a Circular Supply Chain",
          content: "How implementing circular economy principles transformed logistics...",
          company_id: 4,
          published: true,
          metrics: {
            waste_reduced: 85,
            materials_recycled: 92,
            cost_savings: 1200000
          },
          engagement_metrics: {
            views: 98,
            likes: 14,
            shares: 7,
            comments: 3
          },
          created_at: new Date()
        }
      ]);
      
      console.log('Test stories created successfully');
    } else {
      console.log('Stories collection already has data, skipping...');
    }
    
    // Theses collection test data
    const thesesCollection = await getCollection('theses');
    
    // Check if theses collection already has data
    const thesisCount = await thesesCollection.countDocuments({});
    if (thesisCount === 0) {
      console.log('Creating test theses...');
      
      // Insert sample theses
      await thesesCollection.insertMany([
        {
          name: "Climate Tech 2.0",
          content: "Investment thesis focused on next-generation climate technologies...",
          fund_id: 2,
          sector: "CleanTech",
          status: "active",
          key_criteria: [
            "Carbon impact measurement",
            "Scalable technology",
            "Unit economics viability"
          ],
          created_at: new Date(),
          sustainability_focus: true
        },
        {
          name: "Sustainable Food Systems",
          content: "Investment approach for transforming food production and distribution...",
          fund_id: 3,
          sector: "AgriTech",
          status: "active",
          key_criteria: [
            "Water usage efficiency",
            "Land use reduction",
            "Carbon footprint"
          ],
          created_at: new Date(),
          sustainability_focus: true
        }
      ]);
      
      console.log('Test theses created successfully');
    } else {
      console.log('Theses collection already has data, skipping...');
    }
    
    console.log('Test data creation completed successfully');
    return true;
  } catch (error) {
    console.error('Error creating test data:', error);
    return false;
  }
}

/**
 * Main function to initialize MongoDB and create test data
 * @returns {Promise<boolean>} True if successful, false otherwise
 */
export async function initializeMongoDBWithTestData(): Promise<boolean> {
  try {
    // Initialize MongoDB
    const initialized = await initializeMongoDB();
    if (!initialized) {
      return false;
    }
    
    // Create test data
    const testDataCreated = await createTestData();
    
    return testDataCreated;
  } catch (error) {
    console.error('Error in MongoDB initialization process:', error);
    return false;
  } finally {
    // Don't close connection here, as it might be needed by the application
    // await closeMongoDbConnection();
  }
}

// Run initialization if this file is executed directly
if (require.main === module) {
  (async () => {
    const success = await initializeMongoDBWithTestData();
    
    if (success) {
      console.log('MongoDB initialization and test data creation successful');
      process.exit(0);
    } else {
      console.error('MongoDB initialization or test data creation failed');
      process.exit(1);
    }
  })().catch(error => {
    console.error('Uncaught error in MongoDB initialization:', error);
    process.exit(1);
  });
}