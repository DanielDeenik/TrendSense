import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import { 
  companies, 
  documents, 
  funds, 
  patterns, 
  stories, 
  sustainabilityMetrics,
  InsertFund,
  InsertCompany,
  InsertMetric,
  InsertPattern,
  InsertDocument,
  InsertStory,
  Fund,
  Company,
  SustainabilityMetric,
  Pattern,
  Document,
  Story
} from '../shared/schema';
import { eq } from 'drizzle-orm';

// Interface for storage operations
export interface IStorage {
  // Fund operations
  getFunds(): Promise<Fund[]>;
  getFundById(id: number): Promise<Fund | null>;
  createFund(fund: InsertFund): Promise<Fund>;
  
  // Company operations
  getCompanies(fundId?: number): Promise<Company[]>;
  getCompanyById(id: number): Promise<Company | null>;
  createCompany(company: InsertCompany): Promise<Company>;
  
  // Sustainability metrics operations
  getMetrics(companyId?: number): Promise<SustainabilityMetric[]>;
  getMetricById(id: number): Promise<SustainabilityMetric | null>;
  createMetric(metric: InsertMetric): Promise<SustainabilityMetric>;
  
  // Pattern operations
  getPatterns(): Promise<Pattern[]>;
  getPatternById(id: number): Promise<Pattern | null>;
  createPattern(pattern: InsertPattern): Promise<Pattern>;
  
  // Document operations
  getDocuments(companyId?: number): Promise<Document[]>;
  getDocumentById(id: number): Promise<Document | null>;
  createDocument(document: InsertDocument): Promise<Document>;
  
  // Story operations
  getStories(patternId?: number): Promise<Story[]>;
  getStoryById(id: number): Promise<Story | null>;
  createStory(story: InsertStory): Promise<Story>;
}

// PostgreSQL implementation of the storage interface
export class PostgresStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;
  
  constructor() {
    const connectionString = process.env.DATABASE_URL;
    
    if (!connectionString) {
      throw new Error('DATABASE_URL environment variable is not set');
    }
    
    const client = postgres(connectionString, { max: 10 });
    this.db = drizzle(client);
  }
  
  // Fund operations
  async getFunds(): Promise<Fund[]> {
    return this.db.select().from(funds);
  }
  
  async getFundById(id: number): Promise<Fund | null> {
    const results = await this.db.select().from(funds).where(eq(funds.id, id));
    return results.length ? results[0] : null;
  }
  
  async createFund(fund: InsertFund): Promise<Fund> {
    const results = await this.db.insert(funds).values(fund).returning();
    return results[0];
  }
  
  // Company operations
  async getCompanies(fundId?: number): Promise<Company[]> {
    if (fundId) {
      return this.db.select().from(companies).where(eq(companies.fundId, fundId));
    }
    return this.db.select().from(companies);
  }
  
  async getCompanyById(id: number): Promise<Company | null> {
    const results = await this.db.select().from(companies).where(eq(companies.id, id));
    return results.length ? results[0] : null;
  }
  
  async createCompany(company: InsertCompany): Promise<Company> {
    const results = await this.db.insert(companies).values(company).returning();
    return results[0];
  }
  
  // Sustainability metrics operations
  async getMetrics(companyId?: number): Promise<SustainabilityMetric[]> {
    if (companyId) {
      return this.db.select().from(sustainabilityMetrics).where(eq(sustainabilityMetrics.companyId, companyId));
    }
    return this.db.select().from(sustainabilityMetrics);
  }
  
  async getMetricById(id: number): Promise<SustainabilityMetric | null> {
    const results = await this.db.select().from(sustainabilityMetrics).where(eq(sustainabilityMetrics.id, id));
    return results.length ? results[0] : null;
  }
  
  async createMetric(metric: InsertMetric): Promise<SustainabilityMetric> {
    const results = await this.db.insert(sustainabilityMetrics).values(metric).returning();
    return results[0];
  }
  
  // Pattern operations
  async getPatterns(): Promise<Pattern[]> {
    return this.db.select().from(patterns);
  }
  
  async getPatternById(id: number): Promise<Pattern | null> {
    const results = await this.db.select().from(patterns).where(eq(patterns.id, id));
    return results.length ? results[0] : null;
  }
  
  async createPattern(pattern: InsertPattern): Promise<Pattern> {
    const results = await this.db.insert(patterns).values(pattern).returning();
    return results[0];
  }
  
  // Document operations
  async getDocuments(companyId?: number): Promise<Document[]> {
    if (companyId) {
      return this.db.select().from(documents).where(eq(documents.companyId, companyId));
    }
    return this.db.select().from(documents);
  }
  
  async getDocumentById(id: number): Promise<Document | null> {
    const results = await this.db.select().from(documents).where(eq(documents.id, id));
    return results.length ? results[0] : null;
  }
  
  async createDocument(document: InsertDocument): Promise<Document> {
    const results = await this.db.insert(documents).values(document).returning();
    return results[0];
  }
  
  // Story operations
  async getStories(patternId?: number): Promise<Story[]> {
    if (patternId) {
      return this.db.select().from(stories).where(eq(stories.patternId, patternId));
    }
    return this.db.select().from(stories);
  }
  
  async getStoryById(id: number): Promise<Story | null> {
    const results = await this.db.select().from(stories).where(eq(stories.id, id));
    return results.length ? results[0] : null;
  }
  
  async createStory(story: InsertStory): Promise<Story> {
    const results = await this.db.insert(stories).values(story).returning();
    return results[0];
  }
}

// In-memory storage for development and testing
export class MemStorage implements IStorage {
  private funds: Fund[] = [];
  private companies: Company[] = [];
  private metrics: SustainabilityMetric[] = [];
  private patterns: Pattern[] = [];
  private documents: Document[] = [];
  private stories: Story[] = [];
  
  private nextFundId = 1;
  private nextCompanyId = 1;
  private nextMetricId = 1;
  private nextPatternId = 1;
  private nextDocumentId = 1;
  private nextStoryId = 1;
  
  // Fund operations
  async getFunds(): Promise<Fund[]> {
    return [...this.funds];
  }
  
  async getFundById(id: number): Promise<Fund | null> {
    return this.funds.find(f => f.id === id) || null;
  }
  
  async createFund(fund: InsertFund): Promise<Fund> {
    const newFund: Fund = {
      ...fund,
      id: this.nextFundId++,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.funds.push(newFund);
    return newFund;
  }
  
  // Company operations
  async getCompanies(fundId?: number): Promise<Company[]> {
    if (fundId) {
      return this.companies.filter(c => c.fundId === fundId);
    }
    return [...this.companies];
  }
  
  async getCompanyById(id: number): Promise<Company | null> {
    return this.companies.find(c => c.id === id) || null;
  }
  
  async createCompany(company: InsertCompany): Promise<Company> {
    const newCompany: Company = {
      ...company,
      id: this.nextCompanyId++,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.companies.push(newCompany);
    return newCompany;
  }
  
  // Sustainability metrics operations
  async getMetrics(companyId?: number): Promise<SustainabilityMetric[]> {
    if (companyId) {
      return this.metrics.filter(m => m.companyId === companyId);
    }
    return [...this.metrics];
  }
  
  async getMetricById(id: number): Promise<SustainabilityMetric | null> {
    return this.metrics.find(m => m.id === id) || null;
  }
  
  async createMetric(metric: InsertMetric): Promise<SustainabilityMetric> {
    const newMetric: SustainabilityMetric = {
      ...metric,
      id: this.nextMetricId++,
      timestamp: metric.timestamp || new Date()
    };
    this.metrics.push(newMetric);
    return newMetric;
  }
  
  // Pattern operations
  async getPatterns(): Promise<Pattern[]> {
    return [...this.patterns];
  }
  
  async getPatternById(id: number): Promise<Pattern | null> {
    return this.patterns.find(p => p.id === id) || null;
  }
  
  async createPattern(pattern: InsertPattern): Promise<Pattern> {
    const newPattern: Pattern = {
      ...pattern,
      id: this.nextPatternId++,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.patterns.push(newPattern);
    return newPattern;
  }
  
  // Document operations
  async getDocuments(companyId?: number): Promise<Document[]> {
    if (companyId) {
      return this.documents.filter(d => d.companyId === companyId);
    }
    return [...this.documents];
  }
  
  async getDocumentById(id: number): Promise<Document | null> {
    return this.documents.find(d => d.id === id) || null;
  }
  
  async createDocument(document: InsertDocument): Promise<Document> {
    const newDocument: Document = {
      ...document,
      id: this.nextDocumentId++,
      uploadedAt: new Date()
    };
    this.documents.push(newDocument);
    return newDocument;
  }
  
  // Story operations
  async getStories(patternId?: number): Promise<Story[]> {
    if (patternId) {
      return this.stories.filter(s => s.patternId === patternId);
    }
    return [...this.stories];
  }
  
  async getStoryById(id: number): Promise<Story | null> {
    return this.stories.find(s => s.id === id) || null;
  }
  
  async createStory(story: InsertStory): Promise<Story> {
    const newStory: Story = {
      ...story,
      id: this.nextStoryId++,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.stories.push(newStory);
    return newStory;
  }
}

// Export a storage instance based on environment
export const storage: IStorage = process.env.NODE_ENV === 'production' 
  ? new PostgresStorage()
  : new MemStorage();