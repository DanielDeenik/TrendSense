import { storage } from './storage';
import {
  Pattern,
  InsertPattern,
  Company,
  SustainabilityMetric,
  InsertPatternCompany
} from '../shared/schema';
import { OpenAI } from 'openai';
import dotenv from 'dotenv';

dotenv.config();

// Define pattern types
export enum PatternType {
  TREND = 'trend',
  CORRELATION = 'correlation',
  ANOMALY = 'anomaly',
  CLUSTER = 'cluster',
  FORECAST = 'forecast',
  CROSS_SECTOR = 'cross_sector',
  FEDERATED = 'federated'
}

// Define thresholds and configurations for pattern detection
const CONFIG = {
  CORRELATION_THRESHOLD: 0.7,
  ANOMALY_STD_THRESHOLD: 2.5,
  MIN_DATA_POINTS: 5,
  MAX_COMPANIES_PER_PATTERN: 20,
  CONFIDENCE_THRESHOLD: 0.6,
  SIMILARITY_THRESHOLD: 0.85
};

// Interface for the pattern engine
export interface IPatternEngine {
  // Core methods
  detectPatterns(): Promise<Pattern[]>;
  detectTrends(): Promise<Pattern[]>;
  detectCorrelations(): Promise<Pattern[]>;
  detectAnomalies(): Promise<Pattern[]>;
  detectClusters(): Promise<Pattern[]>;
  generateForecasts(): Promise<Pattern[]>;
  
  // Cross-portfolio methods
  detectCrossSectorPatterns(): Promise<Pattern[]>;
  detectFederatedPatterns(): Promise<Pattern[]>;
  
  // Helper methods
  explainPatternWithAI(pattern: Pattern): Promise<string>;
  getSimilarPatterns(patternId: number): Promise<Pattern[]>;
}

// Implementation of the pattern engine
export class PatternEngine implements IPatternEngine {
  private openai: OpenAI | null = null;

  constructor() {
    // Initialize OpenAI if API key is available
    const apiKey = process.env.OPENAI_API_KEY;
    if (apiKey) {
      this.openai = new OpenAI({ apiKey });
    } else {
      console.warn('OpenAI API key not found. AI-powered pattern explanations will not be available.');
    }
  }

  // Core pattern detection method
  async detectPatterns(): Promise<Pattern[]> {
    console.log('Detecting all patterns...');
    
    const patterns: Pattern[] = [];
    
    // Run all pattern detection methods in parallel
    const [trends, correlations, anomalies, clusters, forecasts, crossSector, federated] = await Promise.all([
      this.detectTrends(),
      this.detectCorrelations(),
      this.detectAnomalies(),
      this.detectClusters(),
      this.generateForecasts(),
      this.detectCrossSectorPatterns(),
      this.detectFederatedPatterns()
    ]);
    
    // Combine all detected patterns
    return [...trends, ...correlations, ...anomalies, ...clusters, ...forecasts, ...crossSector, ...federated];
  }

  // Detect trends in sustainability metrics over time
  async detectTrends(): Promise<Pattern[]> {
    console.log('Detecting trends...');
    
    try {
      // Get all companies
      const companies = await storage.getCompanies();
      const trends: Pattern[] = [];
      
      // Process each company
      for (const company of companies) {
        // Get sustainability metrics for the company
        const metrics = await storage.getSustainabilityMetrics(company.id);
        
        // Skip if not enough data points
        if (metrics.length < CONFIG.MIN_DATA_POINTS) {
          continue;
        }
        
        // Group metrics by name
        const metricsByName = this.groupMetricsByName(metrics);
        
        // Analyze each metric group for trends
        for (const [name, nameMetrics] of Object.entries(metricsByName)) {
          // Sort by timestamp
          const sortedMetrics = nameMetrics.sort((a, b) => 
            new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
          
          // Calculate trend
          const trend = this.calculateTrend(sortedMetrics);
          
          // If trend is significant, create a pattern
          if (Math.abs(trend.slope) > 0.1 && trend.confidence > CONFIG.CONFIDENCE_THRESHOLD) {
            const direction = trend.slope > 0 ? 'increasing' : 'decreasing';
            
            const pattern: InsertPattern = {
              name: `${direction} trend in ${name} for ${company.name}`,
              description: `${company.name} shows a ${direction} trend in ${name} with a confidence of ${(trend.confidence * 100).toFixed(2)}%`,
              pattern_type: PatternType.TREND,
              confidence: trend.confidence,
              detection_method: 'linear_regression',
              data: { 
                slope: trend.slope,
                intercept: trend.intercept,
                r_squared: trend.r_squared,
                metric_name: name,
                company_id: company.id,
                datapoints: sortedMetrics.length
              },
              related_sectors: company.sector ? [company.sector] : null,
              related_metrics: [name]
            };
            
            // Save pattern to database
            const savedPattern = await storage.createPattern(pattern);
            
            // Create pattern-company relationship
            await storage.createPatternCompany({
              pattern_id: savedPattern.id,
              company_id: company.id,
              relevance_score: trend.confidence
            });
            
            // Generate AI explanation if available
            if (this.openai) {
              const explanation = await this.explainPatternWithAI(savedPattern);
              if (explanation) {
                await storage.updatePattern(savedPattern.id, { 
                  ai_explanation: explanation 
                });
                savedPattern.ai_explanation = explanation;
              }
            }
            
            trends.push(savedPattern);
          }
        }
      }
      
      return trends;
    } catch (error) {
      console.error('Error detecting trends:', error);
      return [];
    }
  }

  // Detect correlations between different sustainability metrics
  async detectCorrelations(): Promise<Pattern[]> {
    console.log('Detecting correlations...');
    
    try {
      // Get all companies
      const companies = await storage.getCompanies();
      const correlations: Pattern[] = [];
      
      // Process each company
      for (const company of companies) {
        // Get sustainability metrics for the company
        const metrics = await storage.getSustainabilityMetrics(company.id);
        
        // Skip if not enough data points
        if (metrics.length < CONFIG.MIN_DATA_POINTS) {
          continue;
        }
        
        // Group metrics by name
        const metricsByName = this.groupMetricsByName(metrics);
        const metricNames = Object.keys(metricsByName);
        
        // Check all pairs of metrics for correlations
        for (let i = 0; i < metricNames.length; i++) {
          for (let j = i + 1; j < metricNames.length; j++) {
            const name1 = metricNames[i];
            const name2 = metricNames[j];
            
            const metrics1 = metricsByName[name1];
            const metrics2 = metricsByName[name2];
            
            // Skip if not enough matching data points
            if (metrics1.length < CONFIG.MIN_DATA_POINTS || metrics2.length < CONFIG.MIN_DATA_POINTS) {
              continue;
            }
            
            // Calculate correlation
            const correlation = this.calculateCorrelation(metrics1, metrics2);
            
            // If correlation is significant, create a pattern
            if (Math.abs(correlation.coefficient) > CONFIG.CORRELATION_THRESHOLD) {
              const direction = correlation.coefficient > 0 ? 'positive' : 'negative';
              
              const pattern: InsertPattern = {
                name: `${direction} correlation between ${name1} and ${name2} for ${company.name}`,
                description: `${company.name} shows a ${direction} correlation (${correlation.coefficient.toFixed(2)}) between ${name1} and ${name2}`,
                pattern_type: PatternType.CORRELATION,
                confidence: Math.abs(correlation.coefficient),
                detection_method: 'pearson_correlation',
                data: { 
                  coefficient: correlation.coefficient,
                  metric1: name1,
                  metric2: name2,
                  company_id: company.id,
                  datapoints: correlation.datapoints
                },
                related_sectors: company.sector ? [company.sector] : null,
                related_metrics: [name1, name2]
              };
              
              // Save pattern to database
              const savedPattern = await storage.createPattern(pattern);
              
              // Create pattern-company relationship
              await storage.createPatternCompany({
                pattern_id: savedPattern.id,
                company_id: company.id,
                relevance_score: Math.abs(correlation.coefficient)
              });
              
              // Generate AI explanation if available
              if (this.openai) {
                const explanation = await this.explainPatternWithAI(savedPattern);
                if (explanation) {
                  await storage.updatePattern(savedPattern.id, { 
                    ai_explanation: explanation 
                  });
                  savedPattern.ai_explanation = explanation;
                }
              }
              
              correlations.push(savedPattern);
            }
          }
        }
      }
      
      return correlations;
    } catch (error) {
      console.error('Error detecting correlations:', error);
      return [];
    }
  }

  // Detect anomalies in sustainability metrics
  async detectAnomalies(): Promise<Pattern[]> {
    console.log('Detecting anomalies...');
    
    try {
      // Get all companies
      const companies = await storage.getCompanies();
      const anomalies: Pattern[] = [];
      
      // Process each company
      for (const company of companies) {
        // Get sustainability metrics for the company
        const metrics = await storage.getSustainabilityMetrics(company.id);
        
        // Skip if not enough data points
        if (metrics.length < CONFIG.MIN_DATA_POINTS) {
          continue;
        }
        
        // Group metrics by name
        const metricsByName = this.groupMetricsByName(metrics);
        
        // Check each metric group for anomalies
        for (const [name, nameMetrics] of Object.entries(metricsByName)) {
          // Skip if not enough data points
          if (nameMetrics.length < CONFIG.MIN_DATA_POINTS) {
            continue;
          }
          
          // Calculate statistics
          const values = nameMetrics.map(m => m.value);
          const mean = values.reduce((a, b) => a + b, 0) / values.length;
          const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
          const stdDev = Math.sqrt(variance);
          
          // Find anomalies (values more than threshold standard deviations from the mean)
          const anomalyMetrics = nameMetrics.filter(metric => 
            Math.abs(metric.value - mean) > CONFIG.ANOMALY_STD_THRESHOLD * stdDev);
          
          // If anomalies found, create a pattern
          if (anomalyMetrics.length > 0) {
            const anomalyValues = anomalyMetrics.map(m => ({
              value: m.value,
              timestamp: m.timestamp,
              std_deviations: (m.value - mean) / stdDev
            }));
            
            const pattern: InsertPattern = {
              name: `Anomalies detected in ${name} for ${company.name}`,
              description: `${company.name} has ${anomalyMetrics.length} anomalous values in ${name} exceeding ${CONFIG.ANOMALY_STD_THRESHOLD} standard deviations`,
              pattern_type: PatternType.ANOMALY,
              confidence: 0.8, // Fixed confidence for anomaly detection
              detection_method: 'statistical_outlier',
              data: { 
                mean,
                std_dev: stdDev,
                threshold: CONFIG.ANOMALY_STD_THRESHOLD,
                metric_name: name,
                company_id: company.id,
                anomalies: anomalyValues,
                total_datapoints: nameMetrics.length
              },
              related_sectors: company.sector ? [company.sector] : null,
              related_metrics: [name]
            };
            
            // Save pattern to database
            const savedPattern = await storage.createPattern(pattern);
            
            // Create pattern-company relationship
            await storage.createPatternCompany({
              pattern_id: savedPattern.id,
              company_id: company.id,
              relevance_score: 0.8
            });
            
            // Generate AI explanation if available
            if (this.openai) {
              const explanation = await this.explainPatternWithAI(savedPattern);
              if (explanation) {
                await storage.updatePattern(savedPattern.id, { 
                  ai_explanation: explanation 
                });
                savedPattern.ai_explanation = explanation;
              }
            }
            
            anomalies.push(savedPattern);
          }
        }
      }
      
      return anomalies;
    } catch (error) {
      console.error('Error detecting anomalies:', error);
      return [];
    }
  }

  // Simple clustering of companies based on sustainability metrics
  async detectClusters(): Promise<Pattern[]> {
    console.log('Detecting clusters...');
    
    try {
      // Get all companies
      const companies = await storage.getCompanies();
      
      // Skip if not enough companies
      if (companies.length < CONFIG.MIN_DATA_POINTS) {
        return [];
      }
      
      // Get all sustainability metrics
      const allMetrics = await storage.getSustainabilityMetrics();
      
      // Skip if not enough metrics
      if (allMetrics.length < CONFIG.MIN_DATA_POINTS) {
        return [];
      }
      
      // Get distinct metric names
      const metricNames = [...new Set(allMetrics.map(m => m.name))];
      
      const clusters: Pattern[] = [];
      
      // For each metric name, try to find clusters
      for (const metricName of metricNames) {
        // Get all metrics with this name
        const metrics = allMetrics.filter(m => m.name === metricName);
        
        // Create a map of company ID to the average metric value
        const companyMetrics = new Map<number, number>();
        
        for (const metric of metrics) {
          const companyId = metric.company_id;
          const currentSum = companyMetrics.get(companyId) || 0;
          const currentCount = companyMetrics.get(companyId) !== undefined ? 1 : 0;
          
          companyMetrics.set(
            companyId,
            (currentSum + metric.value) / (currentCount + 1)
          );
        }
        
        // Skip if not enough companies have this metric
        if (companyMetrics.size < CONFIG.MIN_DATA_POINTS) {
          continue;
        }
        
        // Very simple clustering: just divide into high, medium, and low groups
        const values = Array.from(companyMetrics.values());
        
        // Calculate thresholds
        const min = Math.min(...values);
        const max = Math.max(...values);
        const range = max - min;
        const lowThreshold = min + range / 3;
        const highThreshold = max - range / 3;
        
        // Create clusters
        const lowCluster: number[] = [];
        const mediumCluster: number[] = [];
        const highCluster: number[] = [];
        
        for (const [companyId, value] of companyMetrics.entries()) {
          if (value < lowThreshold) {
            lowCluster.push(companyId);
          } else if (value > highThreshold) {
            highCluster.push(companyId);
          } else {
            mediumCluster.push(companyId);
          }
        }
        
        // Create patterns for non-empty clusters
        const createClusterPattern = async (
          clusterName: string,
          companyIds: number[],
          threshold: string
        ) => {
          if (companyIds.length < 2) {
            return null;
          }
          
          const clusterCompanies = companies.filter(c => companyIds.includes(c.id));
          const sectors = [...new Set(clusterCompanies.filter(c => c.sector).map(c => c.sector))] as string[];
          
          const pattern: InsertPattern = {
            name: `${clusterName} ${metricName} cluster`,
            description: `Cluster of ${companyIds.length} companies with ${clusterName} ${metricName} values ${threshold}`,
            pattern_type: PatternType.CLUSTER,
            confidence: 0.7, // Fixed confidence for clustering
            detection_method: 'threshold_clustering',
            data: { 
              metric_name: metricName,
              cluster_type: clusterName,
              threshold,
              company_count: companyIds.length,
              company_ids: companyIds
            },
            related_sectors: sectors.length > 0 ? sectors : null,
            related_metrics: [metricName]
          };
          
          // Save pattern to database
          const savedPattern = await storage.createPattern(pattern);
          
          // Create pattern-company relationships
          for (const companyId of companyIds) {
            await storage.createPatternCompany({
              pattern_id: savedPattern.id,
              company_id: companyId,
              relevance_score: 0.7
            });
          }
          
          // Generate AI explanation if available
          if (this.openai) {
            const explanation = await this.explainPatternWithAI(savedPattern);
            if (explanation) {
              await storage.updatePattern(savedPattern.id, { 
                ai_explanation: explanation 
              });
              savedPattern.ai_explanation = explanation;
            }
          }
          
          return savedPattern;
        };
        
        // Create patterns for each cluster
        const lowPattern = await createClusterPattern(
          'low',
          lowCluster,
          `below ${lowThreshold.toFixed(2)} ${metrics[0].unit}`
        );
        
        const mediumPattern = await createClusterPattern(
          'medium',
          mediumCluster,
          `between ${lowThreshold.toFixed(2)} and ${highThreshold.toFixed(2)} ${metrics[0].unit}`
        );
        
        const highPattern = await createClusterPattern(
          'high',
          highCluster,
          `above ${highThreshold.toFixed(2)} ${metrics[0].unit}`
        );
        
        // Add non-null patterns to result
        if (lowPattern) clusters.push(lowPattern);
        if (mediumPattern) clusters.push(mediumPattern);
        if (highPattern) clusters.push(highPattern);
      }
      
      return clusters;
    } catch (error) {
      console.error('Error detecting clusters:', error);
      return [];
    }
  }

  // Generate forecasts for sustainability metrics
  async generateForecasts(): Promise<Pattern[]> {
    console.log('Generating forecasts...');
    
    try {
      // Get all companies
      const companies = await storage.getCompanies();
      const forecasts: Pattern[] = [];
      
      // Process each company
      for (const company of companies) {
        // Get sustainability metrics for the company
        const metrics = await storage.getSustainabilityMetrics(company.id);
        
        // Skip if not enough data points
        if (metrics.length < CONFIG.MIN_DATA_POINTS) {
          continue;
        }
        
        // Group metrics by name
        const metricsByName = this.groupMetricsByName(metrics);
        
        // Generate forecast for each metric group
        for (const [name, nameMetrics] of Object.entries(metricsByName)) {
          // Sort by timestamp
          const sortedMetrics = nameMetrics.sort((a, b) => 
            new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
          
          // Skip if not enough data points
          if (sortedMetrics.length < CONFIG.MIN_DATA_POINTS) {
            continue;
          }
          
          // Calculate trend (simple linear regression)
          const trend = this.calculateTrend(sortedMetrics);
          
          // Skip if trend is not reliable
          if (trend.confidence < CONFIG.CONFIDENCE_THRESHOLD) {
            continue;
          }
          
          // Generate forecast (next 3 periods)
          const lastTimestamp = new Date(sortedMetrics[sortedMetrics.length - 1].timestamp);
          const forecastPeriods = 3;
          const periodInDays = 90; // Assume quarterly data
          
          const forecasts: { timestamp: Date; value: number }[] = [];
          
          for (let i = 1; i <= forecastPeriods; i++) {
            const forecastTimestamp = new Date(lastTimestamp);
            forecastTimestamp.setDate(lastTimestamp.getDate() + i * periodInDays);
            
            const x = sortedMetrics.length + i;
            const forecastValue = trend.slope * x + trend.intercept;
            
            forecasts.push({
              timestamp: forecastTimestamp,
              value: forecastValue
            });
          }
          
          const direction = trend.slope > 0 ? 'increase' : 'decrease';
          const unit = sortedMetrics[0].unit;
          
          const pattern: InsertPattern = {
            name: `${name} forecast for ${company.name}`,
            description: `Forecast predicts ${direction} in ${name} for ${company.name} with confidence ${(trend.confidence * 100).toFixed(2)}%`,
            pattern_type: PatternType.FORECAST,
            confidence: trend.confidence,
            detection_method: 'linear_regression',
            data: { 
              slope: trend.slope,
              intercept: trend.intercept,
              r_squared: trend.r_squared,
              metric_name: name,
              company_id: company.id,
              historical_datapoints: sortedMetrics.length,
              forecast_periods: forecastPeriods,
              forecasts: forecasts.map(f => ({
                timestamp: f.timestamp,
                value: f.value,
                unit
              }))
            },
            related_sectors: company.sector ? [company.sector] : null,
            related_metrics: [name]
          };
          
          // Save pattern to database
          const savedPattern = await storage.createPattern(pattern);
          
          // Create pattern-company relationship
          await storage.createPatternCompany({
            pattern_id: savedPattern.id,
            company_id: company.id,
            relevance_score: trend.confidence
          });
          
          // Generate AI explanation if available
          if (this.openai) {
            const explanation = await this.explainPatternWithAI(savedPattern);
            if (explanation) {
              await storage.updatePattern(savedPattern.id, { 
                ai_explanation: explanation 
              });
              savedPattern.ai_explanation = explanation;
            }
          }
          
          forecasts.push(savedPattern);
        }
      }
      
      return forecasts;
    } catch (error) {
      console.error('Error generating forecasts:', error);
      return [];
    }
  }

  // Detect patterns across different sectors
  async detectCrossSectorPatterns(): Promise<Pattern[]> {
    console.log('Detecting cross-sector patterns...');
    
    try {
      // Get all companies
      const companies = await storage.getCompanies();
      
      // Group companies by sector
      const sectorCompanies = new Map<string, Company[]>();
      
      for (const company of companies) {
        if (!company.sector) continue;
        
        const companiesInSector = sectorCompanies.get(company.sector) || [];
        companiesInSector.push(company);
        sectorCompanies.set(company.sector, companiesInSector);
      }
      
      // Skip if not enough sectors
      if (sectorCompanies.size < 2) {
        return [];
      }
      
      const crossSectorPatterns: Pattern[] = [];
      
      // Get all sustainability metrics
      const allMetrics = await storage.getSustainabilityMetrics();
      
      // Get distinct metric names
      const metricNames = [...new Set(allMetrics.map(m => m.name))];
      
      // For each metric name, check for cross-sector patterns
      for (const metricName of metricNames) {
        // Get all metrics with this name
        const metrics = allMetrics.filter(m => m.name === metricName);
        
        // Calculate sector averages
        const sectorAverages = new Map<string, { avg: number; count: number }>();
        
        for (const metric of metrics) {
          const company = companies.find(c => c.id === metric.company_id);
          if (!company || !company.sector) continue;
          
          const sector = company.sector;
          const current = sectorAverages.get(sector) || { avg: 0, count: 0 };
          
          current.avg = (current.avg * current.count + metric.value) / (current.count + 1);
          current.count++;
          
          sectorAverages.set(sector, current);
        }
        
        // Skip if not enough sectors have this metric
        if (sectorAverages.size < 2) {
          continue;
        }
        
        // Find the sector with highest and lowest average
        let highestSector: string | null = null;
        let highestAvg = -Infinity;
        let lowestSector: string | null = null;
        let lowestAvg = Infinity;
        
        for (const [sector, { avg, count }] of sectorAverages.entries()) {
          if (count < CONFIG.MIN_DATA_POINTS) continue;
          
          if (avg > highestAvg) {
            highestAvg = avg;
            highestSector = sector;
          }
          
          if (avg < lowestAvg) {
            lowestAvg = avg;
            lowestSector = sector;
          }
        }
        
        // Skip if couldn't find highest or lowest
        if (!highestSector || !lowestSector || highestSector === lowestSector) {
          continue;
        }
        
        // Calculate the difference
        const difference = highestAvg - lowestAvg;
        
        // Skip if difference is not significant (more than 20%)
        if (difference / lowestAvg < 0.2) {
          continue;
        }
        
        // Get companies in these sectors
        const highSectorCompanies = sectorCompanies.get(highestSector) || [];
        const lowSectorCompanies = sectorCompanies.get(lowestSector) || [];
        
        // Create a cross-sector pattern
        const unit = metrics[0].unit;
        const pattern: InsertPattern = {
          name: `${metricName} sector difference: ${highestSector} vs ${lowestSector}`,
          description: `${highestSector} sector has ${(difference / lowestAvg * 100).toFixed(2)}% higher ${metricName} than ${lowestSector} sector`,
          pattern_type: PatternType.CROSS_SECTOR,
          confidence: 0.8, // Fixed confidence for cross-sector analysis
          detection_method: 'sector_average_comparison',
          data: { 
            metric_name: metricName,
            high_sector: highestSector,
            high_avg: highestAvg,
            low_sector: lowestSector,
            low_avg: lowestAvg,
            difference,
            percentage_difference: (difference / lowestAvg * 100),
            unit
          },
          related_sectors: [highestSector, lowestSector],
          related_metrics: [metricName]
        };
        
        // Save pattern to database
        const savedPattern = await storage.createPattern(pattern);
        
        // Create pattern-company relationships for both sectors
        const allCompanies = [...highSectorCompanies, ...lowSectorCompanies];
        for (const company of allCompanies.slice(0, CONFIG.MAX_COMPANIES_PER_PATTERN)) {
          await storage.createPatternCompany({
            pattern_id: savedPattern.id,
            company_id: company.id,
            relevance_score: company.sector === highestSector ? 0.9 : 0.7
          });
        }
        
        // Generate AI explanation if available
        if (this.openai) {
          const explanation = await this.explainPatternWithAI(savedPattern);
          if (explanation) {
            await storage.updatePattern(savedPattern.id, { 
              ai_explanation: explanation 
            });
            savedPattern.ai_explanation = explanation;
          }
        }
        
        crossSectorPatterns.push(savedPattern);
      }
      
      return crossSectorPatterns;
    } catch (error) {
      console.error('Error detecting cross-sector patterns:', error);
      return [];
    }
  }

  // Detect federated patterns (patterns that appear across multiple funds)
  async detectFederatedPatterns(): Promise<Pattern[]> {
    console.log('Detecting federated patterns...');
    
    try {
      // Get all funds
      const funds = await storage.getFunds();
      
      // Skip if not enough funds
      if (funds.length < 2) {
        return [];
      }
      
      // Get existing patterns
      const existingPatterns = await storage.getPatterns();
      
      // Skip if not enough patterns
      if (existingPatterns.length < CONFIG.MIN_DATA_POINTS) {
        return [];
      }
      
      const federatedPatterns: Pattern[] = [];
      
      // Group patterns by type and metric name
      const patternGroups = new Map<string, Pattern[]>();
      
      for (const pattern of existingPatterns) {
        // Skip federated patterns to avoid recursion
        if (pattern.pattern_type === PatternType.FEDERATED) {
          continue;
        }
        
        // Get the metric name from the pattern data
        let metricName = '';
        
        if (pattern.data && typeof pattern.data === 'object' && 'metric_name' in pattern.data) {
          metricName = pattern.data.metric_name as string;
        } else if (pattern.related_metrics && pattern.related_metrics.length > 0) {
          metricName = pattern.related_metrics[0];
        } else {
          continue;
        }
        
        const key = `${pattern.pattern_type}:${metricName}`;
        const group = patternGroups.get(key) || [];
        group.push(pattern);
        patternGroups.set(key, group);
      }
      
      // For each group with enough patterns, check for federated patterns
      for (const [key, patterns] of patternGroups.entries()) {
        if (patterns.length < 3) {
          continue;
        }
        
        const [patternType, metricName] = key.split(':');
        
        // Calculate the average confidence
        const avgConfidence = patterns.reduce((sum, p) => sum + (p.confidence || 0), 0) / patterns.length;
        
        // Find all companies involved in these patterns
        const companyPatterns = new Map<number, Pattern[]>();
        
        for (const pattern of patterns) {
          // Get companies for this pattern
          const patternCompanies = await storage.getPatternCompanies(pattern.id);
          
          for (const pc of patternCompanies) {
            const companyPatternList = companyPatterns.get(pc.company_id) || [];
            companyPatternList.push(pattern);
            companyPatterns.set(pc.company_id, companyPatternList);
          }
        }
        
        // Get companies with multiple related patterns
        const companiesWithMultiplePatterns = [...companyPatterns.entries()]
          .filter(([_, patterns]) => patterns.length > 1)
          .map(([companyId, _]) => companyId);
        
        if (companiesWithMultiplePatterns.length < 3) {
          continue;
        }
        
        // Fetch actual company objects
        const companies = await Promise.all(
          companiesWithMultiplePatterns.map(id => storage.getCompanyById(id))
        );
        
        // Count companies by fund
        const fundCompanyCounts = new Map<number, number>();
        
        for (const company of companies) {
          if (!company || !company.fund_id) continue;
          
          const count = fundCompanyCounts.get(company.fund_id) || 0;
          fundCompanyCounts.set(company.fund_id, count + 1);
        }
        
        // Check if pattern appears in multiple funds
        const fundsWithPattern = [...fundCompanyCounts.entries()]
          .filter(([_, count]) => count >= 2)
          .map(([fundId, _]) => fundId);
        
        if (fundsWithPattern.length < 2) {
          continue;
        }
        
        // Create a federated pattern
        const federatedPattern: InsertPattern = {
          name: `Federated ${patternType} pattern for ${metricName}`,
          description: `${metricName} shows a consistent ${patternType} pattern across ${fundsWithPattern.length} different funds`,
          pattern_type: PatternType.FEDERATED,
          confidence: avgConfidence * 0.9, // Slightly reduce confidence for federated patterns
          detection_method: 'cross_fund_pattern_analysis',
          data: { 
            base_pattern_type: patternType,
            metric_name: metricName,
            fund_count: fundsWithPattern.length,
            company_count: companiesWithMultiplePatterns.length,
            source_pattern_count: patterns.length,
            fund_ids: fundsWithPattern,
            pattern_ids: patterns.map(p => p.id)
          },
          related_sectors: patterns.flatMap(p => p.related_sectors || [])
            .filter((v, i, a) => a.indexOf(v) === i), // Deduplicate
          related_metrics: [metricName],
          is_federated: true,
          federated_sources: patterns.map(p => ({ pattern_id: p.id, pattern_type: p.pattern_type }))
        };
        
        // Save pattern to database
        const savedPattern = await storage.createPattern(federatedPattern);
        
        // Create pattern-company relationships
        for (const companyId of companiesWithMultiplePatterns.slice(0, CONFIG.MAX_COMPANIES_PER_PATTERN)) {
          await storage.createPatternCompany({
            pattern_id: savedPattern.id,
            company_id: companyId,
            relevance_score: avgConfidence * 0.9
          });
        }
        
        // Generate AI explanation if available
        if (this.openai) {
          const explanation = await this.explainPatternWithAI(savedPattern);
          if (explanation) {
            await storage.updatePattern(savedPattern.id, { 
              ai_explanation: explanation 
            });
            savedPattern.ai_explanation = explanation;
          }
        }
        
        federatedPatterns.push(savedPattern);
      }
      
      return federatedPatterns;
    } catch (error) {
      console.error('Error detecting federated patterns:', error);
      return [];
    }
  }

  // Use OpenAI to explain a pattern
  async explainPatternWithAI(pattern: Pattern): Promise<string> {
    if (!this.openai) {
      return '';
    }
    
    try {
      const prompt = this.generatePatternPrompt(pattern);
      
      const response = await this.openai.chat.completions.create({
        model: "gpt-4-turbo-preview",  // Use an appropriate model
        messages: [
          {
            role: "system",
            content: "You are an expert in sustainability analytics and venture capital investments. Your task is to explain detected patterns in sustainability metrics data in a clear, insightful way that highlights business implications."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 500,
        temperature: 0.7
      });
      
      return response.choices[0].message.content || '';
    } catch (error) {
      console.error('Error generating AI explanation:', error);
      return '';
    }
  }

  // Generate a prompt for OpenAI based on the pattern
  private generatePatternPrompt(pattern: Pattern): string {
    let prompt = `Please explain the following pattern in sustainability metrics:\n\n`;
    prompt += `Pattern Name: ${pattern.name}\n`;
    prompt += `Pattern Type: ${pattern.pattern_type}\n`;
    prompt += `Description: ${pattern.description}\n`;
    prompt += `Confidence: ${pattern.confidence}\n`;
    prompt += `Detection Method: ${pattern.detection_method}\n`;
    
    if (pattern.related_sectors && pattern.related_sectors.length > 0) {
      prompt += `Related Sectors: ${pattern.related_sectors.join(', ')}\n`;
    }
    
    if (pattern.related_metrics && pattern.related_metrics.length > 0) {
      prompt += `Related Metrics: ${pattern.related_metrics.join(', ')}\n`;
    }
    
    prompt += `\nPattern Data: ${JSON.stringify(pattern.data, null, 2)}\n\n`;
    
    prompt += `Please provide:\n`;
    prompt += `1. A clear explanation of what this pattern means\n`;
    prompt += `2. Potential business implications for the companies involved\n`;
    prompt += `3. Actionable insights for venture capital investors\n`;
    prompt += `4. How this relates to broader sustainability trends\n\n`;
    
    prompt += `Keep your response concise but insightful, around 250-300 words.`;
    
    return prompt;
  }

  // Find patterns similar to a given pattern
  async getSimilarPatterns(patternId: number): Promise<Pattern[]> {
    try {
      // Get the target pattern
      const pattern = await storage.getPatternById(patternId);
      if (!pattern) {
        return [];
      }
      
      // Get all patterns of the same type
      const allPatterns = await storage.getPatterns();
      const similarTypePatterns = allPatterns.filter(p => 
        p.id !== pattern.id && p.pattern_type === pattern.pattern_type);
      
      if (similarTypePatterns.length === 0) {
        return [];
      }
      
      // Calculate similarity scores
      const scoredPatterns = similarTypePatterns.map(p => {
        let score = 0;
        
        // Metric name similarity
        if (pattern.data && p.data && 
            'metric_name' in pattern.data && 'metric_name' in p.data &&
            pattern.data.metric_name === p.data.metric_name) {
          score += 0.4;
        }
        
        // Sector overlap
        if (pattern.related_sectors && p.related_sectors) {
          const overlapCount = pattern.related_sectors.filter(s => 
            p.related_sectors?.includes(s)).length;
          const maxPossible = Math.min(
            pattern.related_sectors.length, 
            p.related_sectors.length
          );
          
          if (maxPossible > 0) {
            score += 0.3 * (overlapCount / maxPossible);
          }
        }
        
        // Metric overlap
        if (pattern.related_metrics && p.related_metrics) {
          const overlapCount = pattern.related_metrics.filter(m => 
            p.related_metrics?.includes(m)).length;
          const maxPossible = Math.min(
            pattern.related_metrics.length, 
            p.related_metrics.length
          );
          
          if (maxPossible > 0) {
            score += 0.3 * (overlapCount / maxPossible);
          }
        }
        
        return { pattern: p, score };
      });
      
      // Sort by similarity score and filter by threshold
      return scoredPatterns
        .filter(item => item.score >= CONFIG.SIMILARITY_THRESHOLD)
        .sort((a, b) => b.score - a.score)
        .map(item => item.pattern);
    } catch (error) {
      console.error('Error finding similar patterns:', error);
      return [];
    }
  }

  // Helper method to group metrics by name
  private groupMetricsByName(metrics: SustainabilityMetric[]): Record<string, SustainabilityMetric[]> {
    const result: Record<string, SustainabilityMetric[]> = {};
    
    for (const metric of metrics) {
      if (!result[metric.name]) {
        result[metric.name] = [];
      }
      result[metric.name].push(metric);
    }
    
    return result;
  }

  // Helper method to calculate trend using simple linear regression
  private calculateTrend(metrics: SustainabilityMetric[]): {
    slope: number;
    intercept: number;
    r_squared: number;
    confidence: number;
  } {
    // Use simple linear regression (y = mx + b)
    // x is the index (0, 1, 2, ...), y is the metric value
    const n = metrics.length;
    
    // Calculate means
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumXX = 0;
    let sumYY = 0;
    
    for (let i = 0; i < n; i++) {
      const x = i;
      const y = metrics[i].value;
      
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
      sumYY += y * y;
    }
    
    const meanX = sumX / n;
    const meanY = sumY / n;
    
    // Calculate slope and intercept
    const numerator = sumXY - sumX * sumY / n;
    const denominator = sumXX - sumX * sumX / n;
    
    if (denominator === 0) {
      return { slope: 0, intercept: meanY, r_squared: 0, confidence: 0 };
    }
    
    const slope = numerator / denominator;
    const intercept = meanY - slope * meanX;
    
    // Calculate R-squared
    let ssr = 0; // Sum of squared regression
    let sst = 0; // Total sum of squares
    
    for (let i = 0; i < n; i++) {
      const x = i;
      const y = metrics[i].value;
      const yHat = slope * x + intercept;
      
      ssr += Math.pow(yHat - meanY, 2);
      sst += Math.pow(y - meanY, 2);
    }
    
    const r_squared = sst === 0 ? 0 : ssr / sst;
    
    // Map R-squared to confidence (R-squared is between 0 and 1)
    const confidence = Math.sqrt(r_squared);
    
    return { slope, intercept, r_squared, confidence };
  }

  // Helper method to calculate correlation between two sets of metrics
  private calculateCorrelation(metrics1: SustainabilityMetric[], metrics2: SustainabilityMetric[]): {
    coefficient: number;
    datapoints: number;
  } {
    // Group metrics by timestamp
    const metricsByTimestamp = new Map<string, { m1?: number; m2?: number }>();
    
    for (const metric of metrics1) {
      const timestamp = new Date(metric.timestamp).toISOString();
      const entry = metricsByTimestamp.get(timestamp) || {};
      entry.m1 = metric.value;
      metricsByTimestamp.set(timestamp, entry);
    }
    
    for (const metric of metrics2) {
      const timestamp = new Date(metric.timestamp).toISOString();
      const entry = metricsByTimestamp.get(timestamp) || {};
      entry.m2 = metric.value;
      metricsByTimestamp.set(timestamp, entry);
    }
    
    // Filter for entries that have both metrics
    const pairs = [...metricsByTimestamp.values()]
      .filter(entry => entry.m1 !== undefined && entry.m2 !== undefined) as { m1: number; m2: number }[];
    
    if (pairs.length < CONFIG.MIN_DATA_POINTS) {
      return { coefficient: 0, datapoints: pairs.length };
    }
    
    // Calculate Pearson correlation coefficient
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumXX = 0;
    let sumYY = 0;
    
    for (const { m1, m2 } of pairs) {
      sumX += m1;
      sumY += m2;
      sumXY += m1 * m2;
      sumXX += m1 * m1;
      sumYY += m2 * m2;
    }
    
    const n = pairs.length;
    const numerator = n * sumXY - sumX * sumY;
    const denominator = Math.sqrt((n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY));
    
    if (denominator === 0) {
      return { coefficient: 0, datapoints: n };
    }
    
    const coefficient = numerator / denominator;
    
    return { coefficient, datapoints: n };
  }
}

// Create and export the pattern engine instance
export const patternEngine = new PatternEngine();