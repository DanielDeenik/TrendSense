/**
 * Thesis Service for MongoDB
 * 
 * This service provides operations for investment thesis documents,
 * including sector-based filtering and search capabilities.
 */

import { ObjectId } from 'mongodb';
import { 
  getCollection, 
  toObjectId, 
  serializeMongoDocument, 
  serializeMongoDocuments 
} from '../mongodb_connection';

// Thesis collection name
const COLLECTION_NAME = 'theses';

// Thesis interface
export interface Thesis {
  _id?: string | ObjectId;
  name: string;
  content: string;
  fund_id: number;
  sector: string;
  key_criteria: string[];
  created_at: Date;
  updated_at?: Date;
  author?: string;
  summary?: string;
  status?: 'draft' | 'active' | 'archived';
  investment_stage?: 'seed' | 'early' | 'growth' | 'late';
  target_metrics?: {
    [key: string]: {
      min?: number;
      max?: number;
      target?: number;
      unit?: string;
    };
  };
  sustainability_focus?: boolean;
}

// Thesis service class
export class ThesisService {
  /**
   * Create a new thesis
   * @param {Thesis} thesis - Thesis to create
   * @returns {Promise<Thesis>} Created thesis
   */
  async createThesis(thesis: Omit<Thesis, '_id'>): Promise<Thesis> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Ensure created_at is set
      const newThesis = {
        ...thesis,
        created_at: new Date(),
        status: thesis.status || 'draft'
      };
      
      const result = await collection.insertOne(newThesis);
      
      return {
        ...newThesis,
        _id: result.insertedId.toString()
      } as Thesis;
    } catch (error) {
      console.error('Error creating thesis:', error);
      throw new Error(`Failed to create thesis: ${error}`);
    }
  }
  
  /**
   * Get thesis by ID
   * @param {string} id - Thesis ID
   * @returns {Promise<Thesis|null>} Thesis or null if not found
   */
  async getThesisById(id: string): Promise<Thesis | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const thesis = await collection.findOne({ _id: toObjectId(id) });
      
      return thesis ? serializeMongoDocument(thesis) as Thesis : null;
    } catch (error) {
      console.error(`Error getting thesis ${id}:`, error);
      throw new Error(`Failed to get thesis: ${error}`);
    }
  }
  
  /**
   * Get all theses, optionally filtered by fund and sector
   * @param {number} fundId - Optional fund ID filter
   * @param {string} sector - Optional sector filter
   * @param {string} status - Optional status filter
   * @param {number} limit - Optional limit of theses to return
   * @param {number} skip - Optional number of theses to skip
   * @returns {Promise<Thesis[]>} List of theses
   */
  async getAllTheses(
    fundId?: number,
    sector?: string,
    status?: 'draft' | 'active' | 'archived',
    limit: number = 50,
    skip: number = 0
  ): Promise<Thesis[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {};
      if (fundId !== undefined) filter.fund_id = fundId;
      if (sector) filter.sector = sector;
      if (status) filter.status = status;
      
      // Execute query
      const theses = await collection
        .find(filter)
        .sort({ created_at: -1 })
        .limit(limit)
        .skip(skip)
        .toArray();
      
      return serializeMongoDocuments(theses) as Thesis[];
    } catch (error) {
      console.error('Error getting theses:', error);
      throw new Error(`Failed to get theses: ${error}`);
    }
  }
  
  /**
   * Update an existing thesis
   * @param {string} id - Thesis ID
   * @param {Partial<Thesis>} updates - Thesis updates
   * @returns {Promise<Thesis|null>} Updated thesis or null if not found
   */
  async updateThesis(id: string, updates: Partial<Thesis>): Promise<Thesis | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Set updated_at timestamp
      const updateData = {
        ...updates,
        updated_at: new Date()
      };
      
      // Remove _id from updates if present
      if ('_id' in updateData) {
        delete updateData._id;
      }
      
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(id) },
        { $set: updateData },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Thesis : null;
    } catch (error) {
      console.error(`Error updating thesis ${id}:`, error);
      throw new Error(`Failed to update thesis: ${error}`);
    }
  }
  
  /**
   * Delete a thesis
   * @param {string} id - Thesis ID
   * @returns {Promise<boolean>} True if deleted, false if not found
   */
  async deleteThesis(id: string): Promise<boolean> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const result = await collection.deleteOne({ _id: toObjectId(id) });
      
      return result.deletedCount > 0;
    } catch (error) {
      console.error(`Error deleting thesis ${id}:`, error);
      throw new Error(`Failed to delete thesis: ${error}`);
    }
  }
  
  /**
   * Update thesis status
   * @param {string} id - Thesis ID
   * @param {string} status - New status
   * @returns {Promise<Thesis|null>} Updated thesis or null if not found
   */
  async updateThesisStatus(
    id: string,
    status: 'draft' | 'active' | 'archived'
  ): Promise<Thesis | null> {
    try {
      return this.updateThesis(id, { status });
    } catch (error) {
      console.error(`Error updating thesis status ${id}:`, error);
      throw new Error(`Failed to update thesis status: ${error}`);
    }
  }
  
  /**
   * Search theses by text query
   * @param {string} query - Text search query
   * @param {number} fundId - Optional fund ID filter
   * @param {number} limit - Optional limit of theses to return
   * @returns {Promise<Thesis[]>} List of matching theses
   */
  async searchTheses(
    query: string,
    fundId?: number,
    limit: number = 20
  ): Promise<Thesis[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {
        $text: { $search: query }
      };
      
      if (fundId !== undefined) filter.fund_id = fundId;
      
      // Execute query
      const theses = await collection
        .find(filter)
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(theses) as Thesis[];
    } catch (error) {
      console.error(`Error searching theses for "${query}":`, error);
      throw new Error(`Failed to search theses: ${error}`);
    }
  }
  
  /**
   * Get sustainability-focused theses
   * @param {number} limit - Limit of theses to return
   * @returns {Promise<Thesis[]>} List of sustainability-focused theses
   */
  async getSustainabilityTheses(limit: number = 20): Promise<Thesis[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const theses = await collection
        .find({ sustainability_focus: true, status: 'active' })
        .sort({ created_at: -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(theses) as Thesis[];
    } catch (error) {
      console.error('Error getting sustainability theses:', error);
      throw new Error(`Failed to get sustainability theses: ${error}`);
    }
  }
  
  /**
   * Get thesis count by fund
   * @param {number} fundId - Fund ID
   * @returns {Promise<number>} Thesis count
   */
  async getThesisCountByFund(fundId: number): Promise<number> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      return await collection.countDocuments({ fund_id: fundId });
    } catch (error) {
      console.error(`Error getting thesis count for fund ${fundId}:`, error);
      throw new Error(`Failed to get thesis count: ${error}`);
    }
  }
  
  /**
   * Get theses by sector
   * @param {string} sector - Sector name
   * @param {number} limit - Limit of theses to return
   * @returns {Promise<Thesis[]>} List of theses in the specified sector
   */
  async getThesesBySector(sector: string, limit: number = 20): Promise<Thesis[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const theses = await collection
        .find({ sector, status: 'active' })
        .sort({ created_at: -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(theses) as Thesis[];
    } catch (error) {
      console.error(`Error getting theses by sector ${sector}:`, error);
      throw new Error(`Failed to get theses by sector: ${error}`);
    }
  }
}

// Export singleton instance
export const thesisService = new ThesisService();