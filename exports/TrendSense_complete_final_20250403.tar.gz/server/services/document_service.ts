/**
 * Document Service for MongoDB
 * 
 * This service provides CRUD operations for sustainability documents,
 * including advanced search capabilities and document analysis.
 */

import { ObjectId } from 'mongodb';
import { 
  getCollection, 
  toObjectId, 
  serializeMongoDocument, 
  serializeMongoDocuments 
} from '../mongodb_connection';

// Document collection name
const COLLECTION_NAME = 'documents';

// Document interface
export interface Document {
  _id?: string | ObjectId;
  title: string;
  content: string;
  company_id: number;
  fund_id: number;
  tags: string[];
  created_at: Date;
  updated_at?: Date;
  metadata: {
    author?: string;
    pages?: number;
    format?: string;
    sustainability_score?: number;
    analysis_status?: 'pending' | 'processing' | 'completed' | 'failed';
    analysis_results?: any;
  };
}

// Document service class
export class DocumentService {
  /**
   * Get all documents, optionally filtered by company or fund
   * @param {number} companyId - Optional company ID filter
   * @param {number} fundId - Optional fund ID filter
   * @param {number} limit - Optional limit of documents to return
   * @param {number} skip - Optional number of documents to skip
   * @returns {Promise<Document[]>} List of documents
   */
  async getAllDocuments(
    companyId?: number,
    fundId?: number,
    limit: number = 50,
    skip: number = 0
  ): Promise<Document[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {};
      if (companyId !== undefined) filter.company_id = companyId;
      if (fundId !== undefined) filter.fund_id = fundId;
      
      // Execute query
      const documents = await collection
        .find(filter)
        .sort({ created_at: -1 })
        .limit(limit)
        .skip(skip)
        .toArray();
      
      return serializeMongoDocuments(documents) as Document[];
    } catch (error) {
      console.error('Error getting documents:', error);
      throw new Error(`Failed to get documents: ${error}`);
    }
  }
  
  /**
   * Get document by ID
   * @param {string} id - Document ID
   * @returns {Promise<Document|null>} Document or null if not found
   */
  async getDocumentById(id: string): Promise<Document | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const document = await collection.findOne({ _id: toObjectId(id) });
      
      return document ? serializeMongoDocument(document) as Document : null;
    } catch (error) {
      console.error(`Error getting document ${id}:`, error);
      throw new Error(`Failed to get document: ${error}`);
    }
  }
  
  /**
   * Create a new document
   * @param {Document} document - Document to create
   * @returns {Promise<Document>} Created document
   */
  async createDocument(document: Omit<Document, '_id'>): Promise<Document> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Ensure created_at is set
      const newDocument = {
        ...document,
        created_at: new Date()
      };
      
      const result = await collection.insertOne(newDocument);
      
      return {
        ...newDocument,
        _id: result.insertedId.toString()
      } as Document;
    } catch (error) {
      console.error('Error creating document:', error);
      throw new Error(`Failed to create document: ${error}`);
    }
  }
  
  /**
   * Update an existing document
   * @param {string} id - Document ID
   * @param {Partial<Document>} updates - Document updates
   * @returns {Promise<Document|null>} Updated document or null if not found
   */
  async updateDocument(id: string, updates: Partial<Document>): Promise<Document | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Set updated_at timestamp
      const updateData = {
        ...updates,
        updated_at: new Date()
      };
      
      // Remove _id from updates if present
      if ('_id' in updateData) {
        delete updateData._id;
      }
      
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(id) },
        { $set: updateData },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Document : null;
    } catch (error) {
      console.error(`Error updating document ${id}:`, error);
      throw new Error(`Failed to update document: ${error}`);
    }
  }
  
  /**
   * Delete a document
   * @param {string} id - Document ID
   * @returns {Promise<boolean>} True if deleted, false if not found
   */
  async deleteDocument(id: string): Promise<boolean> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const result = await collection.deleteOne({ _id: toObjectId(id) });
      
      return result.deletedCount > 0;
    } catch (error) {
      console.error(`Error deleting document ${id}:`, error);
      throw new Error(`Failed to delete document: ${error}`);
    }
  }
  
  /**
   * Search documents by text query
   * @param {string} query - Text search query
   * @param {number} companyId - Optional company ID filter
   * @param {number} fundId - Optional fund ID filter
   * @param {string[]} tags - Optional tags to filter by
   * @param {number} limit - Optional limit of documents to return
   * @returns {Promise<Document[]>} List of matching documents
   */
  async searchDocuments(
    query: string,
    companyId?: number,
    fundId?: number,
    tags?: string[],
    limit: number = 20
  ): Promise<Document[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {};
      
      // Add text search if query is provided
      if (query && query.trim() !== '') {
        filter.$text = { $search: query };
      }
      
      // Add additional filters
      if (companyId !== undefined) filter.company_id = companyId;
      if (fundId !== undefined) filter.fund_id = fundId;
      if (tags && tags.length > 0) filter.tags = { $in: tags };
      
      // Execute query
      const documents = await collection
        .find(filter)
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(documents) as Document[];
    } catch (error) {
      console.error('Error searching documents:', error);
      throw new Error(`Failed to search documents: ${error}`);
    }
  }
  
  /**
   * Get documents by tag
   * @param {string} tag - Tag to filter by
   * @param {number} limit - Optional limit of documents to return
   * @returns {Promise<Document[]>} List of documents with the specified tag
   */
  async getDocumentsByTag(tag: string, limit: number = 20): Promise<Document[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const documents = await collection
        .find({ tags: tag })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(documents) as Document[];
    } catch (error) {
      console.error(`Error getting documents by tag ${tag}:`, error);
      throw new Error(`Failed to get documents by tag: ${error}`);
    }
  }
  
  /**
   * Update document analysis results
   * @param {string} id - Document ID
   * @param {any} analysisResults - Analysis results
   * @param {number} sustainabilityScore - Sustainability score
   * @returns {Promise<Document|null>} Updated document or null if not found
   */
  async updateDocumentAnalysis(
    id: string, 
    analysisResults: any, 
    sustainabilityScore: number
  ): Promise<Document | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(id) },
        { 
          $set: { 
            'metadata.analysis_results': analysisResults,
            'metadata.sustainability_score': sustainabilityScore,
            'metadata.analysis_status': 'completed',
            updated_at: new Date()
          } 
        },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Document : null;
    } catch (error) {
      console.error(`Error updating document analysis ${id}:`, error);
      throw new Error(`Failed to update document analysis: ${error}`);
    }
  }
  
  /**
   * Get top sustainability documents by score
   * @param {number} limit - Limit of documents to return
   * @returns {Promise<Document[]>} List of top-rated sustainability documents
   */
  async getTopSustainabilityDocuments(limit: number = 10): Promise<Document[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const documents = await collection
        .find({ 'metadata.sustainability_score': { $exists: true } })
        .sort({ 'metadata.sustainability_score': -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(documents) as Document[];
    } catch (error) {
      console.error('Error getting top sustainability documents:', error);
      throw new Error(`Failed to get top sustainability documents: ${error}`);
    }
  }
  
  /**
   * Get document count by company
   * @param {number} companyId - Company ID
   * @returns {Promise<number>} Document count
   */
  async getDocumentCountByCompany(companyId: number): Promise<number> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      return await collection.countDocuments({ company_id: companyId });
    } catch (error) {
      console.error(`Error getting document count for company ${companyId}:`, error);
      throw new Error(`Failed to get document count: ${error}`);
    }
  }
}

// Export singleton instance
export const documentService = new DocumentService();