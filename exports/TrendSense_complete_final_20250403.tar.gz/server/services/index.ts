/**
 * MongoDB Services Index
 * 
 * This file exports all MongoDB service singletons for the TrendSense VC Platform.
 * Use these services for MongoDB operations in the application.
 */

import { documentService } from './document_service';
import { patternService } from './pattern_service';
import { storyService } from './story_service';
import { thesisService } from './thesis_service';

// Export all services
export {
  documentService,
  patternService,
  storyService,
  thesisService
};

// Export interfaces
export type { Document } from './document_service';
export type { Pattern } from './pattern_service';
export type { Story } from './story_service';
export type { Thesis } from './thesis_service';