/**
 * Pattern Service for MongoDB
 * 
 * This service provides operations for investment patterns,
 * including federated pattern analysis and pattern detection.
 */

import { ObjectId } from 'mongodb';
import { 
  getCollection, 
  toObjectId, 
  serializeMongoDocument, 
  serializeMongoDocuments 
} from '../mongodb_connection';

// Pattern collection name
const COLLECTION_NAME = 'patterns';

// Pattern interface
export interface Pattern {
  _id?: string | ObjectId;
  name: string;
  description: string;
  sector: string;
  confidence: number;
  supporting_data: {
    company_count: number;
    avg_roi?: number;
    timeframe?: string;
    detected_at?: Date;
    supporting_companies?: number[];
    supporting_metrics?: any;
  };
  created_at: Date;
  updated_at?: Date;
  ai_explanation?: string;
  correlation_strength?: number;
  trend_direction?: 'increasing' | 'decreasing' | 'stable';
  trend_velocity?: number;
  similar_patterns?: string[];
}

// Pattern service class
export class PatternService {
  /**
   * Create a new pattern
   * @param {Pattern} pattern - Pattern to create
   * @returns {Promise<Pattern>} Created pattern
   */
  async createPattern(pattern: Omit<Pattern, '_id'>): Promise<Pattern> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Ensure created_at is set
      const newPattern = {
        ...pattern,
        created_at: new Date()
      };
      
      const result = await collection.insertOne(newPattern);
      
      return {
        ...newPattern,
        _id: result.insertedId.toString()
      } as Pattern;
    } catch (error) {
      console.error('Error creating pattern:', error);
      throw new Error(`Failed to create pattern: ${error}`);
    }
  }
  
  /**
   * Get pattern by ID
   * @param {string} id - Pattern ID
   * @returns {Promise<Pattern|null>} Pattern or null if not found
   */
  async getPatternById(id: string): Promise<Pattern | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const pattern = await collection.findOne({ _id: toObjectId(id) });
      
      return pattern ? serializeMongoDocument(pattern) as Pattern : null;
    } catch (error) {
      console.error(`Error getting pattern ${id}:`, error);
      throw new Error(`Failed to get pattern: ${error}`);
    }
  }
  
  /**
   * Get all patterns, optionally filtered by sector
   * @param {string} sector - Optional sector filter
   * @param {number} confidenceThreshold - Optional confidence threshold
   * @param {number} limit - Optional limit of patterns to return
   * @param {number} skip - Optional number of patterns to skip
   * @returns {Promise<Pattern[]>} List of patterns
   */
  async getAllPatterns(
    sector?: string,
    confidenceThreshold: number = 0,
    limit: number = 50,
    skip: number = 0
  ): Promise<Pattern[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {};
      if (sector) filter.sector = sector;
      if (confidenceThreshold > 0) filter.confidence = { $gte: confidenceThreshold };
      
      // Execute query
      const patterns = await collection
        .find(filter)
        .sort({ confidence: -1 })
        .limit(limit)
        .skip(skip)
        .toArray();
      
      return serializeMongoDocuments(patterns) as Pattern[];
    } catch (error) {
      console.error('Error getting patterns:', error);
      throw new Error(`Failed to get patterns: ${error}`);
    }
  }
  
  /**
   * Get patterns by trend direction
   * @param {string} direction - Trend direction ('increasing', 'decreasing', 'stable')
   * @param {number} limit - Optional limit of patterns to return
   * @returns {Promise<Pattern[]>} List of patterns with the specified trend direction
   */
  async getPatternsByTrendDirection(
    direction: 'increasing' | 'decreasing' | 'stable',
    limit: number = 20
  ): Promise<Pattern[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const patterns = await collection
        .find({ trend_direction: direction })
        .sort({ trend_velocity: -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(patterns) as Pattern[];
    } catch (error) {
      console.error(`Error getting patterns by trend direction ${direction}:`, error);
      throw new Error(`Failed to get patterns by trend direction: ${error}`);
    }
  }
  
  /**
   * Update an existing pattern
   * @param {string} id - Pattern ID
   * @param {Partial<Pattern>} updates - Pattern updates
   * @returns {Promise<Pattern|null>} Updated pattern or null if not found
   */
  async updatePattern(id: string, updates: Partial<Pattern>): Promise<Pattern | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Set updated_at timestamp
      const updateData = {
        ...updates,
        updated_at: new Date()
      };
      
      // Remove _id from updates if present
      if ('_id' in updateData) {
        delete updateData._id;
      }
      
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(id) },
        { $set: updateData },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Pattern : null;
    } catch (error) {
      console.error(`Error updating pattern ${id}:`, error);
      throw new Error(`Failed to update pattern: ${error}`);
    }
  }
  
  /**
   * Delete a pattern
   * @param {string} id - Pattern ID
   * @returns {Promise<boolean>} True if deleted, false if not found
   */
  async deletePattern(id: string): Promise<boolean> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const result = await collection.deleteOne({ _id: toObjectId(id) });
      
      return result.deletedCount > 0;
    } catch (error) {
      console.error(`Error deleting pattern ${id}:`, error);
      throw new Error(`Failed to delete pattern: ${error}`);
    }
  }
  
  /**
   * Update pattern AI explanation
   * @param {string} id - Pattern ID
   * @param {string} explanation - AI-generated explanation
   * @returns {Promise<Pattern|null>} Updated pattern or null if not found
   */
  async updatePatternExplanation(id: string, explanation: string): Promise<Pattern | null> {
    try {
      return this.updatePattern(id, { ai_explanation: explanation });
    } catch (error) {
      console.error(`Error updating pattern explanation ${id}:`, error);
      throw new Error(`Failed to update pattern explanation: ${error}`);
    }
  }
  
  /**
   * Get similar patterns
   * @param {string} id - Pattern ID
   * @param {number} limit - Optional limit of similar patterns to return
   * @returns {Promise<Pattern[]>} List of similar patterns
   */
  async getSimilarPatterns(id: string, limit: number = 5): Promise<Pattern[]> {
    try {
      const pattern = await this.getPatternById(id);
      if (!pattern) {
        throw new Error(`Pattern with ID ${id} not found`);
      }
      
      const collection = await getCollection(COLLECTION_NAME);
      
      // Find patterns in the same sector with similar confidence
      const similarPatterns = await collection
        .find({
          _id: { $ne: toObjectId(id) },
          sector: pattern.sector,
          confidence: { $gte: pattern.confidence - 0.2, $lte: pattern.confidence + 0.2 }
        })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(similarPatterns) as Pattern[];
    } catch (error) {
      console.error(`Error getting similar patterns for ${id}:`, error);
      throw new Error(`Failed to get similar patterns: ${error}`);
    }
  }
  
  /**
   * Get top patterns by confidence
   * @param {number} limit - Limit of patterns to return
   * @returns {Promise<Pattern[]>} List of top patterns
   */
  async getTopPatterns(limit: number = 10): Promise<Pattern[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const patterns = await collection
        .find({})
        .sort({ confidence: -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(patterns) as Pattern[];
    } catch (error) {
      console.error('Error getting top patterns:', error);
      throw new Error(`Failed to get top patterns: ${error}`);
    }
  }
  
  /**
   * Update pattern trend data
   * @param {string} id - Pattern ID
   * @param {string} direction - Trend direction
   * @param {number} velocity - Trend velocity
   * @returns {Promise<Pattern|null>} Updated pattern or null if not found
   */
  async updatePatternTrend(
    id: string,
    direction: 'increasing' | 'decreasing' | 'stable',
    velocity: number
  ): Promise<Pattern | null> {
    try {
      return this.updatePattern(id, { 
        trend_direction: direction,
        trend_velocity: velocity
      });
    } catch (error) {
      console.error(`Error updating pattern trend ${id}:`, error);
      throw new Error(`Failed to update pattern trend: ${error}`);
    }
  }
  
  /**
   * Search patterns by text query
   * @param {string} query - Text search query
   * @param {number} limit - Optional limit of patterns to return
   * @returns {Promise<Pattern[]>} List of matching patterns
   */
  async searchPatterns(query: string, limit: number = 20): Promise<Pattern[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const patterns = await collection
        .find({ $text: { $search: query } })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(patterns) as Pattern[];
    } catch (error) {
      console.error(`Error searching patterns for "${query}":`, error);
      throw new Error(`Failed to search patterns: ${error}`);
    }
  }
  
  /**
   * Add similar pattern reference
   * @param {string} patternId - Pattern ID
   * @param {string} similarPatternId - Similar pattern ID to add
   * @returns {Promise<Pattern|null>} Updated pattern or null if not found
   */
  async addSimilarPattern(patternId: string, similarPatternId: string): Promise<Pattern | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Add similarPatternId to the similar_patterns array if it doesn't already exist
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(patternId) },
        { 
          $addToSet: { similar_patterns: similarPatternId },
          $set: { updated_at: new Date() }
        },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Pattern : null;
    } catch (error) {
      console.error(`Error adding similar pattern ${similarPatternId} to ${patternId}:`, error);
      throw new Error(`Failed to add similar pattern: ${error}`);
    }
  }
}

// Export singleton instance
export const patternService = new PatternService();