/**
 * Story Service for MongoDB
 * 
 * This service provides operations for sustainability storytelling content,
 * including metrics tracking and rich content models.
 */

import { ObjectId } from 'mongodb';
import { 
  getCollection, 
  toObjectId, 
  serializeMongoDocument, 
  serializeMongoDocuments 
} from '../mongodb_connection';

// Story collection name
const COLLECTION_NAME = 'stories';

// Story interface
export interface Story {
  _id?: string | ObjectId;
  title: string;
  content: string;
  company_id: number;
  fund_id?: number;
  metrics?: {
    carbon_reduced?: number;
    water_saved?: number;
    renewable_energy?: number;
    waste_reduced?: number;
    materials_recycled?: number;
    cost_savings?: number;
    [key: string]: number | undefined;
  };
  engagement_metrics?: {
    views: number;
    likes: number;
    shares: number;
    comments: number;
  };
  created_at: Date;
  updated_at?: Date;
  published: boolean;
  author?: string;
  tags?: string[];
  media?: {
    type: 'image' | 'video' | 'chart';
    url: string;
    caption?: string;
  }[];
  framework?: 'mckinsey' | 'gri' | 'sasb' | 'tcfd' | 'custom';
}

// Story service class
export class StoryService {
  /**
   * Create a new story
   * @param {Story} story - Story to create
   * @returns {Promise<Story>} Created story
   */
  async createStory(story: Omit<Story, '_id'>): Promise<Story> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Ensure created_at and engagement_metrics are set
      const newStory = {
        ...story,
        created_at: new Date(),
        engagement_metrics: story.engagement_metrics || {
          views: 0,
          likes: 0,
          shares: 0,
          comments: 0
        }
      };
      
      const result = await collection.insertOne(newStory);
      
      return {
        ...newStory,
        _id: result.insertedId.toString()
      } as Story;
    } catch (error) {
      console.error('Error creating story:', error);
      throw new Error(`Failed to create story: ${error}`);
    }
  }
  
  /**
   * Get story by ID
   * @param {string} id - Story ID
   * @returns {Promise<Story|null>} Story or null if not found
   */
  async getStoryById(id: string): Promise<Story | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const story = await collection.findOne({ _id: toObjectId(id) });
      
      return story ? serializeMongoDocument(story) as Story : null;
    } catch (error) {
      console.error(`Error getting story ${id}:`, error);
      throw new Error(`Failed to get story: ${error}`);
    }
  }
  
  /**
   * Get all stories, optionally filtered by company
   * @param {number} companyId - Optional company ID filter
   * @param {boolean} publishedOnly - Only return published stories
   * @param {number} limit - Optional limit of stories to return
   * @param {number} skip - Optional number of stories to skip
   * @returns {Promise<Story[]>} List of stories
   */
  async getAllStories(
    companyId?: number,
    publishedOnly: boolean = true,
    limit: number = 50,
    skip: number = 0
  ): Promise<Story[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {};
      if (companyId !== undefined) filter.company_id = companyId;
      if (publishedOnly) filter.published = true;
      
      // Execute query
      const stories = await collection
        .find(filter)
        .sort({ created_at: -1 })
        .limit(limit)
        .skip(skip)
        .toArray();
      
      return serializeMongoDocuments(stories) as Story[];
    } catch (error) {
      console.error('Error getting stories:', error);
      throw new Error(`Failed to get stories: ${error}`);
    }
  }
  
  /**
   * Get top stories by views
   * @param {number} limit - Limit of stories to return
   * @returns {Promise<Story[]>} List of top stories
   */
  async getTopStories(limit: number = 10): Promise<Story[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const stories = await collection
        .find({ published: true })
        .sort({ 'engagement_metrics.views': -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(stories) as Story[];
    } catch (error) {
      console.error('Error getting top stories:', error);
      throw new Error(`Failed to get top stories: ${error}`);
    }
  }
  
  /**
   * Update an existing story
   * @param {string} id - Story ID
   * @param {Partial<Story>} updates - Story updates
   * @returns {Promise<Story|null>} Updated story or null if not found
   */
  async updateStory(id: string, updates: Partial<Story>): Promise<Story | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Set updated_at timestamp
      const updateData = {
        ...updates,
        updated_at: new Date()
      };
      
      // Remove _id from updates if present
      if ('_id' in updateData) {
        delete updateData._id;
      }
      
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(id) },
        { $set: updateData },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Story : null;
    } catch (error) {
      console.error(`Error updating story ${id}:`, error);
      throw new Error(`Failed to update story: ${error}`);
    }
  }
  
  /**
   * Delete a story
   * @param {string} id - Story ID
   * @returns {Promise<boolean>} True if deleted, false if not found
   */
  async deleteStory(id: string): Promise<boolean> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      const result = await collection.deleteOne({ _id: toObjectId(id) });
      
      return result.deletedCount > 0;
    } catch (error) {
      console.error(`Error deleting story ${id}:`, error);
      throw new Error(`Failed to delete story: ${error}`);
    }
  }
  
  /**
   * Publish or unpublish a story
   * @param {string} id - Story ID
   * @param {boolean} published - Publish status
   * @returns {Promise<Story|null>} Updated story or null if not found
   */
  async updatePublishStatus(id: string, published: boolean): Promise<Story | null> {
    try {
      return this.updateStory(id, { published });
    } catch (error) {
      console.error(`Error updating publish status for story ${id}:`, error);
      throw new Error(`Failed to update publish status: ${error}`);
    }
  }
  
  /**
   * Update story engagement metrics
   * @param {string} id - Story ID
   * @param {Object} metrics - Engagement metrics to update
   * @returns {Promise<Story|null>} Updated story or null if not found
   */
  async updateEngagementMetrics(
    id: string,
    metrics: {
      views?: number;
      likes?: number;
      shares?: number;
      comments?: number;
    }
  ): Promise<Story | null> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build update object with increment operators
      const updateObj: any = {};
      if (metrics.views) updateObj['engagement_metrics.views'] = metrics.views;
      if (metrics.likes) updateObj['engagement_metrics.likes'] = metrics.likes;
      if (metrics.shares) updateObj['engagement_metrics.shares'] = metrics.shares;
      if (metrics.comments) updateObj['engagement_metrics.comments'] = metrics.comments;
      
      const result = await collection.findOneAndUpdate(
        { _id: toObjectId(id) },
        { $inc: updateObj, $set: { updated_at: new Date() } },
        { returnDocument: 'after' }
      );
      
      return result.value ? serializeMongoDocument(result.value) as Story : null;
    } catch (error) {
      console.error(`Error updating engagement metrics for story ${id}:`, error);
      throw new Error(`Failed to update engagement metrics: ${error}`);
    }
  }
  
  /**
   * Search stories by text query
   * @param {string} query - Text search query
   * @param {boolean} publishedOnly - Only search published stories
   * @param {number} limit - Optional limit of stories to return
   * @returns {Promise<Story[]>} List of matching stories
   */
  async searchStories(
    query: string,
    publishedOnly: boolean = true,
    limit: number = 20
  ): Promise<Story[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      // Build filter
      const filter: any = {
        $text: { $search: query }
      };
      
      if (publishedOnly) filter.published = true;
      
      const stories = await collection
        .find(filter)
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(stories) as Story[];
    } catch (error) {
      console.error(`Error searching stories for "${query}":`, error);
      throw new Error(`Failed to search stories: ${error}`);
    }
  }
  
  /**
   * Get stories by framework
   * @param {string} framework - Framework name
   * @param {number} limit - Limit of stories to return
   * @returns {Promise<Story[]>} List of stories using the specified framework
   */
  async getStoriesByFramework(
    framework: 'mckinsey' | 'gri' | 'sasb' | 'tcfd' | 'custom',
    limit: number = 20
  ): Promise<Story[]> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      
      const stories = await collection
        .find({ framework, published: true })
        .sort({ created_at: -1 })
        .limit(limit)
        .toArray();
      
      return serializeMongoDocuments(stories) as Story[];
    } catch (error) {
      console.error(`Error getting stories by framework ${framework}:`, error);
      throw new Error(`Failed to get stories by framework: ${error}`);
    }
  }
  
  /**
   * Get story count by company
   * @param {number} companyId - Company ID
   * @returns {Promise<number>} Story count
   */
  async getStoryCountByCompany(companyId: number): Promise<number> {
    try {
      const collection = await getCollection(COLLECTION_NAME);
      return await collection.countDocuments({ company_id: companyId });
    } catch (error) {
      console.error(`Error getting story count for company ${companyId}:`, error);
      throw new Error(`Failed to get story count: ${error}`);
    }
  }
}

// Export singleton instance
export const storyService = new StoryService();