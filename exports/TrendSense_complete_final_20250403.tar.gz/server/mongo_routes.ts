/**
 * MongoDB Routes Module
 * 
 * This module provides API routes for MongoDB operations.
 */

import { Router, Request, Response } from 'express';
import { 
  documentService,
  patternService,
  storyService,
  thesisService
} from './services';
import { isMongoDbConnected } from './mongodb_connection';

const router = Router();

/**
 * Middleware to ensure MongoDB connection is established before processing requests
 */
const ensureMongoDbConnection = async (req: Request, res: Response, next: Function) => {
  try {
    const connected = await isMongoDbConnected();
    
    if (connected) {
      next();
    } else {
      res.status(503).json({
        status: 'error',
        message: 'MongoDB connection is not available'
      });
    }
  } catch (error) {
    console.error('Error checking MongoDB connection:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to check MongoDB connection status'
    });
  }
};

// Apply MongoDB connection middleware to all routes
router.use(ensureMongoDbConnection);

// Health check endpoint
router.get('/health', async (req: Request, res: Response) => {
  try {
    const connected = await isMongoDbConnected();
    
    res.json({
      status: connected ? 'ok' : 'error',
      message: connected ? 'MongoDB connection is healthy' : 'MongoDB connection is not available'
    });
  } catch (error) {
    console.error('MongoDB health check error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error checking MongoDB health'
    });
  }
});

// === Document Routes ===

// Get all documents
router.get('/documents', async (req: Request, res: Response) => {
  try {
    const companyId = req.query.company_id ? parseInt(req.query.company_id as string) : undefined;
    const fundId = req.query.fund_id ? parseInt(req.query.fund_id as string) : undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const skip = req.query.skip ? parseInt(req.query.skip as string) : 0;
    
    const documents = await documentService.getAllDocuments(companyId, fundId, limit, skip);
    
    res.json({
      status: 'success',
      data: documents
    });
  } catch (error) {
    console.error('Error getting documents:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve documents'
    });
  }
});

// Get document by ID
router.get('/documents/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const document = await documentService.getDocumentById(id);
    
    if (document) {
      res.json({
        status: 'success',
        data: document
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Document with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error getting document ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve document'
    });
  }
});

// Create a new document
router.post('/documents', async (req: Request, res: Response) => {
  try {
    const documentData = req.body;
    
    // Basic validation
    if (!documentData.title || !documentData.content) {
      return res.status(400).json({
        status: 'error',
        message: 'Title and content are required fields'
      });
    }
    
    const document = await documentService.createDocument(documentData);
    
    res.status(201).json({
      status: 'success',
      data: document
    });
  } catch (error) {
    console.error('Error creating document:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create document'
    });
  }
});

// Update a document
router.put('/documents/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const updates = req.body;
    
    const document = await documentService.updateDocument(id, updates);
    
    if (document) {
      res.json({
        status: 'success',
        data: document
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Document with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error updating document ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update document'
    });
  }
});

// Delete a document
router.delete('/documents/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const result = await documentService.deleteDocument(id);
    
    if (result) {
      res.json({
        status: 'success',
        message: `Document with ID ${id} deleted successfully`
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Document with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error deleting document ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to delete document'
    });
  }
});

// Search documents
router.get('/documents/search', async (req: Request, res: Response) => {
  try {
    const query = req.query.q as string || '';
    const companyId = req.query.company_id ? parseInt(req.query.company_id as string) : undefined;
    const fundId = req.query.fund_id ? parseInt(req.query.fund_id as string) : undefined;
    const tags = req.query.tags ? (req.query.tags as string).split(',') : undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
    
    const documents = await documentService.searchDocuments(query, companyId, fundId, tags, limit);
    
    res.json({
      status: 'success',
      data: documents
    });
  } catch (error) {
    console.error('Error searching documents:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to search documents'
    });
  }
});

// === Pattern Routes ===

// Get all patterns
router.get('/patterns', async (req: Request, res: Response) => {
  try {
    const sector = req.query.sector as string;
    const confidenceThreshold = req.query.confidence ? parseFloat(req.query.confidence as string) : 0;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const skip = req.query.skip ? parseInt(req.query.skip as string) : 0;
    
    const patterns = await patternService.getAllPatterns(sector, confidenceThreshold, limit, skip);
    
    res.json({
      status: 'success',
      data: patterns
    });
  } catch (error) {
    console.error('Error getting patterns:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve patterns'
    });
  }
});

// Get pattern by ID
router.get('/patterns/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const pattern = await patternService.getPatternById(id);
    
    if (pattern) {
      res.json({
        status: 'success',
        data: pattern
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Pattern with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error getting pattern ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve pattern'
    });
  }
});

// Create a new pattern
router.post('/patterns', async (req: Request, res: Response) => {
  try {
    const patternData = req.body;
    
    // Basic validation
    if (!patternData.name || !patternData.description || !patternData.sector) {
      return res.status(400).json({
        status: 'error',
        message: 'Name, description, and sector are required fields'
      });
    }
    
    const pattern = await patternService.createPattern(patternData);
    
    res.status(201).json({
      status: 'success',
      data: pattern
    });
  } catch (error) {
    console.error('Error creating pattern:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create pattern'
    });
  }
});

// Update a pattern
router.put('/patterns/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const updates = req.body;
    
    const pattern = await patternService.updatePattern(id, updates);
    
    if (pattern) {
      res.json({
        status: 'success',
        data: pattern
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Pattern with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error updating pattern ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update pattern'
    });
  }
});

// Delete a pattern
router.delete('/patterns/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const result = await patternService.deletePattern(id);
    
    if (result) {
      res.json({
        status: 'success',
        message: `Pattern with ID ${id} deleted successfully`
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Pattern with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error deleting pattern ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to delete pattern'
    });
  }
});

// Get similar patterns
router.get('/patterns/:id/similar', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
    
    const similarPatterns = await patternService.getSimilarPatterns(id, limit);
    
    res.json({
      status: 'success',
      data: similarPatterns
    });
  } catch (error) {
    console.error(`Error getting similar patterns for ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve similar patterns'
    });
  }
});

// === Story Routes ===

// Get all stories
router.get('/stories', async (req: Request, res: Response) => {
  try {
    const companyId = req.query.company_id ? parseInt(req.query.company_id as string) : undefined;
    const publishedOnly = req.query.published_only !== 'false';
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const skip = req.query.skip ? parseInt(req.query.skip as string) : 0;
    
    const stories = await storyService.getAllStories(companyId, publishedOnly, limit, skip);
    
    res.json({
      status: 'success',
      data: stories
    });
  } catch (error) {
    console.error('Error getting stories:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve stories'
    });
  }
});

// Get top stories
router.get('/stories/top', async (req: Request, res: Response) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    
    const stories = await storyService.getTopStories(limit);
    
    res.json({
      status: 'success',
      data: stories
    });
  } catch (error) {
    console.error('Error getting top stories:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve top stories'
    });
  }
});

// Get story by ID
router.get('/stories/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const story = await storyService.getStoryById(id);
    
    if (story) {
      res.json({
        status: 'success',
        data: story
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Story with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error getting story ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve story'
    });
  }
});

// Create a new story
router.post('/stories', async (req: Request, res: Response) => {
  try {
    const storyData = req.body;
    
    // Basic validation
    if (!storyData.title || !storyData.content || !storyData.company_id) {
      return res.status(400).json({
        status: 'error',
        message: 'Title, content, and company_id are required fields'
      });
    }
    
    const story = await storyService.createStory(storyData);
    
    res.status(201).json({
      status: 'success',
      data: story
    });
  } catch (error) {
    console.error('Error creating story:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create story'
    });
  }
});

// Update a story
router.put('/stories/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const updates = req.body;
    
    const story = await storyService.updateStory(id, updates);
    
    if (story) {
      res.json({
        status: 'success',
        data: story
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Story with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error updating story ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update story'
    });
  }
});

// Delete a story
router.delete('/stories/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const result = await storyService.deleteStory(id);
    
    if (result) {
      res.json({
        status: 'success',
        message: `Story with ID ${id} deleted successfully`
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Story with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error deleting story ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to delete story'
    });
  }
});

// Update story metrics
router.post('/stories/:id/metrics', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const metrics = req.body;
    
    // Basic validation
    if (!metrics || Object.keys(metrics).length === 0) {
      return res.status(400).json({
        status: 'error',
        message: 'Metrics data is required'
      });
    }
    
    const story = await storyService.updateEngagementMetrics(id, metrics);
    
    if (story) {
      res.json({
        status: 'success',
        data: story
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Story with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error updating metrics for story ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update story metrics'
    });
  }
});

// === Thesis Routes ===

// Get all theses
router.get('/theses', async (req: Request, res: Response) => {
  try {
    const fundId = req.query.fund_id ? parseInt(req.query.fund_id as string) : undefined;
    const sector = req.query.sector as string;
    const status = req.query.status as 'draft' | 'active' | 'archived' | undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const skip = req.query.skip ? parseInt(req.query.skip as string) : 0;
    
    const theses = await thesisService.getAllTheses(fundId, sector, status, limit, skip);
    
    res.json({
      status: 'success',
      data: theses
    });
  } catch (error) {
    console.error('Error getting theses:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve theses'
    });
  }
});

// Get thesis by ID
router.get('/theses/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const thesis = await thesisService.getThesisById(id);
    
    if (thesis) {
      res.json({
        status: 'success',
        data: thesis
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Thesis with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error getting thesis ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to retrieve thesis'
    });
  }
});

// Create a new thesis
router.post('/theses', async (req: Request, res: Response) => {
  try {
    const thesisData = req.body;
    
    // Basic validation
    if (!thesisData.name || !thesisData.content || !thesisData.fund_id || !thesisData.sector) {
      return res.status(400).json({
        status: 'error',
        message: 'Name, content, fund_id, and sector are required fields'
      });
    }
    
    const thesis = await thesisService.createThesis(thesisData);
    
    res.status(201).json({
      status: 'success',
      data: thesis
    });
  } catch (error) {
    console.error('Error creating thesis:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to create thesis'
    });
  }
});

// Update a thesis
router.put('/theses/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const updates = req.body;
    
    const thesis = await thesisService.updateThesis(id, updates);
    
    if (thesis) {
      res.json({
        status: 'success',
        data: thesis
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Thesis with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error updating thesis ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to update thesis'
    });
  }
});

// Delete a thesis
router.delete('/theses/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const result = await thesisService.deleteThesis(id);
    
    if (result) {
      res.json({
        status: 'success',
        message: `Thesis with ID ${id} deleted successfully`
      });
    } else {
      res.status(404).json({
        status: 'error',
        message: `Thesis with ID ${id} not found`
      });
    }
  } catch (error) {
    console.error(`Error deleting thesis ${req.params.id}:`, error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to delete thesis'
    });
  }
});

// Search theses
router.get('/theses/search', async (req: Request, res: Response) => {
  try {
    const query = req.query.q as string || '';
    const fundId = req.query.fund_id ? parseInt(req.query.fund_id as string) : undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
    
    const theses = await thesisService.searchTheses(query, fundId, limit);
    
    res.json({
      status: 'success',
      data: theses
    });
  } catch (error) {
    console.error('Error searching theses:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to search theses'
    });
  }
});

export default router;