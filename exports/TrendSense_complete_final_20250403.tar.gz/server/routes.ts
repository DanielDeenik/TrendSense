import express from 'express';
import { storage } from './storage';
import { insertFundSchema, insertCompanySchema, insertMetricSchema, insertPatternSchema, insertDocumentSchema, insertStorySchema } from '../shared/schema';
import { z } from 'zod';

const router = express.Router();

// Health check endpoint
router.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Fund routes
router.get('/api/funds', async (req, res) => {
  try {
    const funds = await storage.getFunds();
    res.json(funds);
  } catch (error) {
    console.error('Error fetching funds:', error);
    res.status(500).json({ error: 'Failed to fetch funds' });
  }
});

router.get('/api/funds/:id', async (req, res) => {
  try {
    const fundId = parseInt(req.params.id);
    const fund = await storage.getFundById(fundId);
    
    if (!fund) {
      return res.status(404).json({ error: 'Fund not found' });
    }
    
    res.json(fund);
  } catch (error) {
    console.error(`Error fetching fund ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch fund' });
  }
});

router.post('/api/funds', async (req, res) => {
  try {
    const validatedData = insertFundSchema.parse(req.body);
    const newFund = await storage.createFund(validatedData);
    res.status(201).json(newFund);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating fund:', error);
    res.status(500).json({ error: 'Failed to create fund' });
  }
});

// Company routes
router.get('/api/companies', async (req, res) => {
  try {
    const fundId = req.query.fundId ? parseInt(req.query.fundId as string) : undefined;
    const companies = await storage.getCompanies(fundId);
    res.json(companies);
  } catch (error) {
    console.error('Error fetching companies:', error);
    res.status(500).json({ error: 'Failed to fetch companies' });
  }
});

router.get('/api/companies/:id', async (req, res) => {
  try {
    const companyId = parseInt(req.params.id);
    const company = await storage.getCompanyById(companyId);
    
    if (!company) {
      return res.status(404).json({ error: 'Company not found' });
    }
    
    res.json(company);
  } catch (error) {
    console.error(`Error fetching company ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch company' });
  }
});

router.post('/api/companies', async (req, res) => {
  try {
    const validatedData = insertCompanySchema.parse(req.body);
    const newCompany = await storage.createCompany(validatedData);
    res.status(201).json(newCompany);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating company:', error);
    res.status(500).json({ error: 'Failed to create company' });
  }
});

// Sustainability metrics routes
router.get('/api/metrics', async (req, res) => {
  try {
    const companyId = req.query.companyId ? parseInt(req.query.companyId as string) : undefined;
    const metrics = await storage.getMetrics(companyId);
    res.json(metrics);
  } catch (error) {
    console.error('Error fetching metrics:', error);
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
});

router.get('/api/metrics/:id', async (req, res) => {
  try {
    const metricId = parseInt(req.params.id);
    const metric = await storage.getMetricById(metricId);
    
    if (!metric) {
      return res.status(404).json({ error: 'Metric not found' });
    }
    
    res.json(metric);
  } catch (error) {
    console.error(`Error fetching metric ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch metric' });
  }
});

router.post('/api/metrics', async (req, res) => {
  try {
    const validatedData = insertMetricSchema.parse(req.body);
    const newMetric = await storage.createMetric(validatedData);
    res.status(201).json(newMetric);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating metric:', error);
    res.status(500).json({ error: 'Failed to create metric' });
  }
});

// Pattern routes
router.get('/api/patterns', async (req, res) => {
  try {
    const patterns = await storage.getPatterns();
    res.json(patterns);
  } catch (error) {
    console.error('Error fetching patterns:', error);
    res.status(500).json({ error: 'Failed to fetch patterns' });
  }
});

router.get('/api/patterns/:id', async (req, res) => {
  try {
    const patternId = parseInt(req.params.id);
    const pattern = await storage.getPatternById(patternId);
    
    if (!pattern) {
      return res.status(404).json({ error: 'Pattern not found' });
    }
    
    res.json(pattern);
  } catch (error) {
    console.error(`Error fetching pattern ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch pattern' });
  }
});

router.post('/api/patterns', async (req, res) => {
  try {
    const validatedData = insertPatternSchema.parse(req.body);
    const newPattern = await storage.createPattern(validatedData);
    res.status(201).json(newPattern);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating pattern:', error);
    res.status(500).json({ error: 'Failed to create pattern' });
  }
});

// Document routes
router.get('/api/documents', async (req, res) => {
  try {
    const companyId = req.query.companyId ? parseInt(req.query.companyId as string) : undefined;
    const documents = await storage.getDocuments(companyId);
    res.json(documents);
  } catch (error) {
    console.error('Error fetching documents:', error);
    res.status(500).json({ error: 'Failed to fetch documents' });
  }
});

router.get('/api/documents/:id', async (req, res) => {
  try {
    const documentId = parseInt(req.params.id);
    const document = await storage.getDocumentById(documentId);
    
    if (!document) {
      return res.status(404).json({ error: 'Document not found' });
    }
    
    res.json(document);
  } catch (error) {
    console.error(`Error fetching document ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch document' });
  }
});

router.post('/api/documents', async (req, res) => {
  try {
    const validatedData = insertDocumentSchema.parse(req.body);
    const newDocument = await storage.createDocument(validatedData);
    res.status(201).json(newDocument);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating document:', error);
    res.status(500).json({ error: 'Failed to create document' });
  }
});

// Story routes
router.get('/api/stories', async (req, res) => {
  try {
    const patternId = req.query.patternId ? parseInt(req.query.patternId as string) : undefined;
    const stories = await storage.getStories(patternId);
    res.json(stories);
  } catch (error) {
    console.error('Error fetching stories:', error);
    res.status(500).json({ error: 'Failed to fetch stories' });
  }
});

router.get('/api/stories/:id', async (req, res) => {
  try {
    const storyId = parseInt(req.params.id);
    const story = await storage.getStoryById(storyId);
    
    if (!story) {
      return res.status(404).json({ error: 'Story not found' });
    }
    
    res.json(story);
  } catch (error) {
    console.error(`Error fetching story ${req.params.id}:`, error);
    res.status(500).json({ error: 'Failed to fetch story' });
  }
});

router.post('/api/stories', async (req, res) => {
  try {
    const validatedData = insertStorySchema.parse(req.body);
    const newStory = await storage.createStory(validatedData);
    res.status(201).json(newStory);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating story:', error);
    res.status(500).json({ error: 'Failed to create story' });
  }
});

// AI-related routes
router.post('/api/ai/explain-pattern', (req, res) => {
  // This would integrate with Google Gemini API in production
  const { patternId, dataPoints } = req.body;
  
  // For now, return a placeholder explanation
  const explanation = `This sustainability pattern shows a correlation between ${dataPoints?.length || 'several'} factors. The data suggests an emerging trend that could impact future sustainability outcomes.`;
  
  res.json({ explanation });
});

export default router;