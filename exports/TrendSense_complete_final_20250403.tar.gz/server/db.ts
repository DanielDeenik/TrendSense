import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from '../shared/schema';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

// Get the DATABASE_URL from environment variables
const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  console.error('DATABASE_URL is not defined in the environment variables');
  process.exit(1);
}

// Configure connection pool
const poolConfig = {
  connectionString: databaseUrl,
  max: 10, // Maximum number of clients in the pool
  idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
  connectionTimeoutMillis: 2000, // Return an error after 2 seconds if connection could not be established
};

// Create a PostgreSQL connection pool
const pool = new Pool(poolConfig);

// Add error handling to the pool
pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});

// Create Drizzle ORM instance
export const db = drizzle(pool, { schema });

// Function to check database connection
export async function checkDatabaseConnection(): Promise<boolean> {
  try {
    const client = await pool.connect();
    console.log('Connected to PostgreSQL database');
    client.release();
    return true;
  } catch (error) {
    console.error('Failed to connect to PostgreSQL database:', error);
    return false;
  }
}

// Function to initialize the database (create tables if they don't exist)
export async function initializeDatabase(): Promise<void> {
  try {
    // We're using the ORM for all operations - we don't need to execute raw SQL
    // We'll use drizzle-kit for migrations
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Export the pool for advanced operations
export { pool };

// Execute immediately to check the connection when this module is loaded
checkDatabaseConnection()
  .then((connected) => {
    if (connected) {
      console.log('Database connection successful');
    } else {
      console.error('Database connection failed');
    }
  })
  .catch((error) => {
    console.error('Database connection check error:', error);
  });