import React from 'react';
import { Route, Switch } from 'wouter';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { Toaster } from '@/components/ui/toaster';

// Layout
import Layout from '@/components/Layout';

// Pages
import DashboardPage from '@/pages/Dashboard';
import CompaniesPage from '@/pages/Companies';
import CompanyDetailPage from '@/pages/CompanyDetail';
import DocumentsPage from '@/pages/Documents';
import PatternsPage from '@/pages/Patterns';
import PatternDetailPage from '@/pages/PatternDetail';
import StoriesPage from '@/pages/Stories';
import StoryDetailPage from '@/pages/StoryDetail';

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <Layout>
        <Switch>
          <Route path="/" component={DashboardPage} />
          <Route path="/companies" component={CompaniesPage} />
          <Route path="/companies/:id" component={CompanyDetailPage} />
          <Route path="/documents" component={DocumentsPage} />
          <Route path="/patterns" component={PatternsPage} />
          <Route path="/patterns/:id" component={PatternDetailPage} />
          <Route path="/stories" component={StoriesPage} />
          <Route path="/stories/:id" component={StoryDetailPage} />
        </Switch>
      </Layout>
      <Toaster />
    </QueryClientProvider>
  );
};

export default App;