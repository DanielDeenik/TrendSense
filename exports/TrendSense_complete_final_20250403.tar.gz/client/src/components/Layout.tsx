import React from 'react';
import { Link, useLocation } from 'wouter';
import {
  BarChart3,
  Building2,
  FileText,
  Home,
  Network,
  BookOpen,
  Settings,
  LogOut,
} from 'lucide-react';

type SidebarLinkProps = {
  href: string;
  icon: React.ReactNode;
  text: string;
  active: boolean;
};

const SidebarLink: React.FC<SidebarLinkProps> = ({ href, icon, text, active }) => {
  return (
    <Link href={href}>
      <a
        className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
          active ? 'bg-muted font-medium text-primary' : 'text-muted-foreground'
        }`}
      >
        {icon}
        <span>{text}</span>
      </a>
    </Link>
  );
};

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [location] = useLocation();

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-10 hidden w-64 border-r bg-card px-4 py-6 md:block">
        <div className="flex items-center gap-2 px-2">
          <div className="rounded-full bg-primary p-1">
            <BarChart3 className="h-6 w-6 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold tracking-tight">SustainaTrend™</span>
        </div>
        
        <nav className="mt-10 flex flex-col gap-1">
          <SidebarLink
            href="/"
            icon={<Home className="h-5 w-5" />}
            text="Dashboard"
            active={location === '/'}
          />
          <SidebarLink
            href="/companies"
            icon={<Building2 className="h-5 w-5" />}
            text="Companies"
            active={location.startsWith('/companies')}
          />
          <SidebarLink
            href="/documents"
            icon={<FileText className="h-5 w-5" />}
            text="Documents"
            active={location.startsWith('/documents')}
          />
          <SidebarLink
            href="/patterns"
            icon={<Network className="h-5 w-5" />}
            text="Patterns"
            active={location.startsWith('/patterns')}
          />
          <SidebarLink
            href="/stories"
            icon={<BookOpen className="h-5 w-5" />}
            text="Stories"
            active={location.startsWith('/stories')}
          />
          
          <div className="my-3 h-px bg-border" />
          
          <SidebarLink
            href="/settings"
            icon={<Settings className="h-5 w-5" />}
            text="Settings"
            active={location.startsWith('/settings')}
          />
        </nav>
        
        <div className="mt-auto">
          <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary">
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
      
      {/* Mobile header */}
      <header className="fixed inset-x-0 top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 md:hidden">
        <button className="rounded-md p-2 hover:bg-accent">
          <BarChart3 className="h-5 w-5" />
        </button>
        <span className="font-semibold">SustainaTrend™</span>
      </header>
      
      {/* Main content */}
      <main className="flex w-full flex-col md:pl-64">
        <div className="container mx-auto p-4 md:p-6">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;