import { QueryClient } from '@tanstack/react-query';

type ApiRequestOptions = {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: any;
  headers?: Record<string, string>;
};

export const apiRequest = async (
  endpoint: string,
  { method = 'GET', body, headers = {} }: ApiRequestOptions = {}
): Promise<any> => {
  const url = endpoint.startsWith('http') ? endpoint : endpoint;
  
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
  };
  
  if (body) {
    options.body = JSON.stringify(body);
  }
  
  const response = await fetch(url, options);
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({
      message: response.statusText,
    }));
    throw new Error(error.message || 'An error occurred');
  }
  
  return response.json();
};

// Default fetcher for React Query
const defaultQueryFn = async ({ queryKey }: { queryKey: unknown[] }): Promise<any> => {
  const endpoint = queryKey[0] as string;
  return apiRequest(endpoint);
};

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: defaultQueryFn,
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
});