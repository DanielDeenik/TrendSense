import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link } from 'wouter';
import { ArrowLeft, Network, Info, Lightbulb, LineChart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Pattern } from '@shared/schema';

const PatternDetail: React.FC = () => {
  const { id } = useParams();
  const patternId = parseInt(id as string);
  
  const { data: pattern, isLoading } = useQuery<Pattern>({
    queryKey: [`/api/patterns/${patternId}`],
    enabled: !!patternId,
  });
  
  const { data: stories } = useQuery({
    queryKey: ['/api/stories', patternId],
    queryFn: () => fetch(`/api/stories?patternId=${patternId}`).then(res => res.json()),
    enabled: !!patternId,
  });

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-32 w-32 animate-pulse rounded-full bg-muted"></div>
      </div>
    );
  }

  if (!pattern) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Pattern not found</h2>
          <p className="mt-2 text-muted-foreground">The pattern you're looking for doesn't exist.</p>
          <Link href="/patterns">
            <Button className="mt-4">Back to Patterns</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2">
          <Link href="/patterns">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Network className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{pattern.name}</h1>
            <p className="text-muted-foreground">{pattern.category} • {pattern.detectionMethod}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <span className="flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary">
            <Info className="h-4 w-4" />
            {(pattern.confidence * 100).toFixed(0)}% confidence
          </span>
          <Button>Generate Story</Button>
        </div>
      </div>

      {/* Pattern Details */}
      <Card>
        <CardHeader>
          <CardTitle>Pattern Details</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{pattern.description}</p>
          
          <div className="mt-6 rounded-md bg-muted/50 p-4">
            <div className="flex items-start gap-2">
              <Lightbulb className="mt-0.5 h-4 w-4 text-amber-500" />
              <div>
                <h3 className="text-sm font-medium">AI Explanation</h3>
                <p className="mt-1 text-sm">{pattern.aiExplanation}</p>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="mb-2 text-sm font-medium">Data Visualization</h3>
            <div className="h-64 rounded-md bg-muted/30 p-4">
              <div className="flex h-full items-center justify-center">
                <LineChart className="h-6 w-6 text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">
                  Visualization would appear here
                </span>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="mb-2 text-sm font-medium">Data Points</h3>
            <div className="rounded-md border">
              <table className="w-full">
                <thead className="bg-muted/50 text-left text-sm">
                  <tr>
                    <th className="px-4 py-2">Company</th>
                    <th className="px-4 py-2">Metric</th>
                    <th className="px-4 py-2 text-right">Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y text-sm">
                  {pattern.dataPoints && pattern.dataPoints.length > 0 ? (
                    pattern.dataPoints.map((point, index) => (
                      <tr key={index}>
                        <td className="px-4 py-2">{point.company}</td>
                        <td className="px-4 py-2">{point.metric}</td>
                        <td className="px-4 py-2 text-right">{point.value}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="px-4 py-8 text-center text-muted-foreground">
                        No data points available
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Related Stories */}
      <div>
        <h2 className="mb-4 text-xl font-semibold">Related Stories</h2>
        {stories && stories.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2">
            {stories.map((story: any) => (
              <Card key={story.id}>
                <CardHeader>
                  <CardTitle className="text-base">{story.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-3 text-sm text-muted-foreground">{story.content}</p>
                </CardContent>
                <CardContent className="flex justify-end border-t px-6 py-3">
                  <Link href={`/stories/${story.id}`}>
                    <Button variant="ghost" size="sm">
                      Read Story
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-6">
            <div className="flex items-center justify-center text-muted-foreground">
              No stories have been generated for this pattern
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default PatternDetail;