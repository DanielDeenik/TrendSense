import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link } from 'wouter';
import { ArrowLeft, Building2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Company, SustainabilityMetric } from '@shared/schema';

const CompanyDetail: React.FC = () => {
  const { id } = useParams();
  const companyId = parseInt(id as string);
  
  const { data: company, isLoading: isLoadingCompany } = useQuery<Company>({
    queryKey: [`/api/companies/${companyId}`],
    enabled: !!companyId,
  });
  
  const { data: metrics, isLoading: isLoadingMetrics } = useQuery<SustainabilityMetric[]>({
    queryKey: ['/api/metrics', companyId],
    queryFn: () => fetch(`/api/metrics?companyId=${companyId}`).then(res => res.json()),
    enabled: !!companyId,
  });

  if (isLoadingCompany) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-32 w-32 animate-pulse rounded-full bg-muted"></div>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Company not found</h2>
          <p className="mt-2 text-muted-foreground">The company you're looking for doesn't exist.</p>
          <Link href="/companies">
            <Button className="mt-4">Back to Companies</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2">
          <Link href="/companies">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Building2 className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{company.name}</h1>
            <p className="text-muted-foreground">{company.sector}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">Edit</Button>
          <Button>Add Metric</Button>
        </div>
      </div>

      {/* Company Details */}
      <Card>
        <CardHeader>
          <CardTitle>Company Details</CardTitle>
        </CardHeader>
        <CardContent>
          <dl className="grid gap-3 sm:grid-cols-2">
            <div>
              <dt className="text-sm font-medium text-muted-foreground">Description</dt>
              <dd className="mt-1">{company.description}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-muted-foreground">Status</dt>
              <dd className="mt-1">
                <span
                  className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                    company.isPublic ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                  }`}
                >
                  {company.isPublic ? 'Public' : 'Private'}
                </span>
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-muted-foreground">Fund ID</dt>
              <dd className="mt-1">{company.fundId}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-muted-foreground">Added</dt>
              <dd className="mt-1">
                {company.createdAt ? new Date(company.createdAt).toLocaleDateString() : 'N/A'}
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="metrics">
        <TabsList>
          <TabsTrigger value="metrics">Sustainability Metrics</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="patterns">Related Patterns</TabsTrigger>
        </TabsList>
        
        <TabsContent value="metrics" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {isLoadingMetrics ? (
              Array(3)
                .fill(0)
                .map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader className="h-24 bg-muted/30"></CardHeader>
                    <CardContent></CardContent>
                  </Card>
                ))
            ) : metrics && metrics.length > 0 ? (
              metrics.map((metric) => (
                <Card key={metric.id}>
                  <CardHeader>
                    <CardTitle className="text-base">{metric.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {metric.value} {metric.unit}
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Category: {metric.category}
                    </p>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="col-span-full p-6">
                <div className="flex items-center justify-center text-muted-foreground">
                  No metrics available for this company
                </div>
              </Card>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="documents" className="pt-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex h-32 items-center justify-center text-muted-foreground">
                Document management would be implemented here
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="patterns" className="pt-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex h-32 items-center justify-center text-muted-foreground">
                Related patterns would be displayed here
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CompanyDetail;