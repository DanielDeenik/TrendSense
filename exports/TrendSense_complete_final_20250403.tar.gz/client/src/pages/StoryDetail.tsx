import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link } from 'wouter';
import { ArrowLeft, BookOpen, CalendarDays, Network, LineChart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Story } from '@shared/schema';

const StoryDetail: React.FC = () => {
  const { id } = useParams();
  const storyId = parseInt(id as string);
  
  const { data: story, isLoading } = useQuery<Story>({
    queryKey: [`/api/stories/${storyId}`],
    enabled: !!storyId,
  });
  
  const { data: pattern } = useQuery({
    queryKey: ['/api/patterns', story?.patternId],
    queryFn: () => story?.patternId ? fetch(`/api/patterns/${story.patternId}`).then(res => res.json()) : null,
    enabled: !!story?.patternId,
  });

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-32 w-32 animate-pulse rounded-full bg-muted"></div>
      </div>
    );
  }

  if (!story) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Story not found</h2>
          <p className="mt-2 text-muted-foreground">The story you're looking for doesn't exist.</p>
          <Link href="/stories">
            <Button className="mt-4">Back to Stories</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2">
          <Link href="/stories">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <BookOpen className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{story.title}</h1>
            <div className="flex items-center gap-2 text-muted-foreground">
              <CalendarDays className="h-3 w-3" />
              <span className="text-sm">
                {new Date(story.createdAt).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">Edit</Button>
          <Button>Share</Button>
        </div>
      </div>

      {/* Story Content */}
      <Card>
        <CardHeader>
          <CardTitle>Story</CardTitle>
        </CardHeader>
        <CardContent className="prose max-w-none">
          <p>{story.content}</p>
          
          <div className="mt-8">
            <h3 className="mb-2 text-lg font-medium">Data Visualization</h3>
            <div className="h-80 rounded-md bg-muted/30 p-4">
              <div className="flex h-full items-center justify-center">
                <LineChart className="h-6 w-6 text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">
                  {story.visualizationType} visualization would appear here
                </span>
              </div>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">
              <p>Visualization shows the relationship between key sustainability metrics over time.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Related Pattern */}
      {pattern && (
        <Card>
          <CardHeader className="flex flex-row items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <Network className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle>Related Pattern</CardTitle>
              <p className="text-sm text-muted-foreground">Based on detected sustainability pattern</p>
            </div>
          </CardHeader>
          <CardContent>
            <h3 className="text-lg font-medium">{pattern.name}</h3>
            <p className="mt-2 text-muted-foreground">{pattern.description}</p>
            
            <div className="mt-4 flex justify-end">
              <Link href={`/patterns/${pattern.id}`}>
                <Button variant="outline">View Pattern Details</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default StoryDetail;