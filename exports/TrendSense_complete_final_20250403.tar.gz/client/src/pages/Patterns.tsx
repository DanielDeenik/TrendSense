import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Network,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  ArrowRight,
  BarChart3,
  LineChart,
} from 'lucide-react';
import { Pattern } from '@shared/schema';

// Chart component (placeholder)
const PatternVisualization: React.FC<{ type: string }> = ({ type }) => {
  const getIcon = () => {
    switch (type) {
      case 'correlation-analysis':
        return <BarChart3 className="h-6 w-6 text-muted-foreground" />;
      case 'trend-analysis':
        return <TrendingUp className="h-6 w-6 text-muted-foreground" />;
      default:
        return <LineChart className="h-6 w-6 text-muted-foreground" />;
    }
  };

  return (
    <div className="mt-4 h-36 rounded-md bg-muted/30 p-4">
      <div className="flex h-full items-center justify-center">
        {getIcon()}
        <span className="ml-2 text-sm text-muted-foreground">
          {type} visualization would appear here
        </span>
      </div>
    </div>
  );
};

const formatConfidence = (confidence: number): string => {
  return `${(confidence * 100).toFixed(0)}%`;
};

const PatternsPage: React.FC = () => {
  const { data: patterns, isLoading } = useQuery<Pattern[]>({
    queryKey: ['/api/patterns'],
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sustainability Patterns</h1>
          <p className="text-muted-foreground">
            Discover AI-detected patterns and insights across your portfolio.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select className="rounded-md border bg-background px-3 py-2 text-sm">
            <option value="all">All Categories</option>
            <option value="emissions">Emissions</option>
            <option value="energy">Energy</option>
            <option value="water">Water</option>
            <option value="governance">Governance</option>
          </select>
          <Button className="flex items-center gap-2">
            <Lightbulb className="h-4 w-4" />
            New Analysis
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="h-24 bg-muted/30"></CardHeader>
              <CardContent className="h-56 bg-muted/20"></CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {patterns && patterns.length > 0 ? (
            patterns.map((pattern) => (
              <Card key={pattern.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Network className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{pattern.name}</CardTitle>
                        <CardDescription className="text-xs">
                          {pattern.category} • {pattern.detectionMethod}
                        </CardDescription>
                      </div>
                    </div>
                    <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
                      {formatConfidence(pattern.confidence)}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{pattern.description}</p>
                  <PatternVisualization type={pattern.detectionMethod} />
                  <div className="mt-4 rounded-md bg-muted/50 p-3">
                    <div className="flex items-start gap-2">
                      <Lightbulb className="mt-0.5 h-4 w-4 text-amber-500" />
                      <p className="text-sm">{pattern.aiExplanation}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t px-6 py-4">
                  <span className="text-sm text-muted-foreground">
                    {pattern.dataPoints?.length || 0} data points
                  </span>
                  <Link href={`/patterns/${pattern.id}`}>
                    <Button variant="ghost" size="sm" className="flex items-center gap-1">
                      View Details
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))
          ) : (
            <Card className="col-span-full p-6">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <AlertTriangle className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium">No patterns detected</h3>
                <p className="max-w-md text-muted-foreground">
                  Add more sustainability metrics or upload more documents to help the AI detect
                  meaningful patterns in your portfolio.
                </p>
                <Button className="mt-2">Run pattern detection</Button>
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default PatternsPage;