import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  BookOpen,
  Lightbulb,
  ChevronRight,
  AlertTriangle,
  BarChart,
  LineChart,
  PieChart,
} from 'lucide-react';
import { Story } from '@shared/schema';

// Chart component (placeholder)
const StoryVisualization: React.FC<{ type: string }> = ({ type }) => {
  const getIcon = () => {
    switch (type) {
      case 'bar-chart':
        return <BarChart className="h-6 w-6 text-muted-foreground" />;
      case 'pie-chart':
        return <PieChart className="h-6 w-6 text-muted-foreground" />;
      default:
        return <LineChart className="h-6 w-6 text-muted-foreground" />;
    }
  };

  return (
    <div className="mt-4 h-36 rounded-md bg-muted/30 p-4">
      <div className="flex h-full items-center justify-center">
        {getIcon()}
        <span className="ml-2 text-sm text-muted-foreground">
          {type} visualization would appear here
        </span>
      </div>
    </div>
  );
};

const StoriesPage: React.FC = () => {
  const { data: stories, isLoading } = useQuery<Story[]>({
    queryKey: ['/api/stories'],
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sustainability Stories</h1>
          <p className="text-muted-foreground">
            AI-generated narratives that explain sustainability trends and opportunities.
          </p>
        </div>
        <Button className="flex items-center gap-2">
          <Lightbulb className="h-4 w-4" />
          Generate Story
        </Button>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2">
          {[1, 2].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="h-24 bg-muted/30"></CardHeader>
              <CardContent className="h-48 bg-muted/20"></CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {stories && stories.length > 0 ? (
            stories.map((story) => (
              <Card key={story.id}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{story.title}</CardTitle>
                      <CardDescription className="text-xs">
                        Pattern ID: {story.patternId} • {story.visualizationType}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground line-clamp-3">{story.content}</p>
                  <StoryVisualization type={story.visualizationType} />
                </CardContent>
                <CardFooter className="flex justify-between border-t px-6 py-4">
                  <span className="text-sm text-muted-foreground">
                    Created: {new Date(story.createdAt).toLocaleDateString()}
                  </span>
                  <Link href={`/stories/${story.id}`}>
                    <Button variant="ghost" size="sm" className="flex items-center gap-1">
                      Read Story
                      <ChevronRight className="h-3 w-3" />
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))
          ) : (
            <Card className="col-span-full p-6">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <AlertTriangle className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium">No stories available</h3>
                <p className="max-w-md text-muted-foreground">
                  Generate your first sustainability story by analyzing patterns in your portfolio.
                </p>
                <Button className="mt-2">Generate your first story</Button>
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default StoriesPage;