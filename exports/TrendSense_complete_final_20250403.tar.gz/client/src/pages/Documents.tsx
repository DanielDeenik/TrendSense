import React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Upload, Search, FileUp } from 'lucide-react';
import { Document } from '@shared/schema';

const DocumentsPage: React.FC = () => {
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Document Repository</h1>
          <p className="text-muted-foreground">
            Upload and analyze sustainability documents across your portfolio.
          </p>
        </div>
        <Button className="flex items-center gap-2">
          <Upload className="h-4 w-4" />
          Upload Document
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading
          ? Array(6)
              .fill(0)
              .map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader className="h-24 bg-muted/30"></CardHeader>
                  <CardContent className="h-12 bg-muted/20"></CardContent>
                </Card>
              ))
          : documents && documents.length > 0
          ? documents.map((doc) => (
              <Card key={doc.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{doc.title}</CardTitle>
                      <CardDescription className="text-xs">
                        Company ID: {doc.companyId}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-2 text-sm text-muted-foreground">{doc.description}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      Uploaded: {new Date(doc.uploadedAt).toLocaleDateString()}
                    </span>
                    <Button variant="ghost" size="sm" className="h-7 text-xs">
                      View
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          : (
              <Card className="col-span-full">
                <CardContent className="flex h-64 flex-col items-center justify-center space-y-4 p-6">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                    <FileUp className="h-10 w-10 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium">No documents yet</h3>
                  <p className="text-center text-muted-foreground">
                    Upload sustainability reports, ESG disclosures, and other documents to analyze.
                  </p>
                  <Button className="mt-2">Upload your first document</Button>
                </CardContent>
              </Card>
            )}
      </div>
    </div>
  );
};

export default DocumentsPage;