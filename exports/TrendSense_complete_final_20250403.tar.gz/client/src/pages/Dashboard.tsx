import React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  BarChart3,
  Leaf,
  Droplets,
  LineChart,
  BarChart,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';
import { SustainabilityMetric } from '@shared/schema';

// Chart component (placeholder)
// In a real implementation, this would use a library like recharts
const MetricChart: React.FC<{ title: string; data: any }> = ({ title, data }) => {
  return (
    <div className="mt-2 h-40 w-full rounded-md bg-muted/30 p-4">
      <div className="flex h-full items-center justify-center">
        <LineChart className="h-6 w-6 text-muted-foreground" />
        <span className="ml-2 text-sm text-muted-foreground">Chart visualization would appear here</span>
      </div>
    </div>
  );
};

const Dashboard: React.FC = () => {
  // Fetch metrics
  const { data: metrics, isLoading } = useQuery<SustainabilityMetric[]>({
    queryKey: ['/api/metrics'],
  });

  // Fetch patterns
  const { data: patterns, isLoading: isLoadingPatterns } = useQuery({
    queryKey: ['/api/patterns'],
  });

  const getMetricIcon = (category: string) => {
    switch (category) {
      case 'emissions':
        return <BarChart3 className="h-5 w-5 text-destructive" />;
      case 'energy':
        return <Leaf className="h-5 w-5 text-green-500" />;
      case 'water':
        return <Droplets className="h-5 w-5 text-blue-500" />;
      case 'governance':
        return <BarChart className="h-5 w-5 text-orange-500" />;
      default:
        return <TrendingUp className="h-5 w-5 text-muted-foreground" />;
    }
  };

  // Format metric value with unit
  const formatMetricValue = (metric: SustainabilityMetric) => {
    return `${metric.value} ${metric.unit}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sustainability Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor key sustainability metrics and patterns across your portfolio.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select className="rounded-md border bg-background px-3 py-2 text-sm">
            <option value="all">All Companies</option>
            <option value="1">EcoTech Solutions</option>
            <option value="2">GreenWater</option>
          </select>
          <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
            Export
          </button>
        </div>
      </div>

      {/* Metrics Overview */}
      <div>
        <h2 className="mb-4 text-xl font-semibold">Key Metrics</h2>
        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader className="h-24 bg-muted/30"></CardHeader>
                <CardContent></CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {metrics && metrics.length > 0 ? (
              metrics.map((metric) => (
                <Card key={metric.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      {getMetricIcon(metric.category)}
                      <span className="text-xl font-bold">{formatMetricValue(metric)}</span>
                    </div>
                    <CardTitle className="text-base font-medium">{metric.name}</CardTitle>
                    <CardDescription className="text-xs">
                      {metric.companyId ? `Company ID: ${metric.companyId}` : 'All Companies'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <MetricChart title={metric.name} data={null} />
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="col-span-full p-6">
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <AlertTriangle className="h-5 w-5" />
                  <span>No metrics available</span>
                </div>
              </Card>
            )}
          </div>
        )}
      </div>

      {/* Patterns and Insights */}
      <div>
        <h2 className="mb-4 text-xl font-semibold">Detected Patterns</h2>
        {isLoadingPatterns ? (
          <div className="animate-pulse space-y-4">
            <Card className="h-32 bg-muted/30"></Card>
            <Card className="h-32 bg-muted/30"></Card>
          </div>
        ) : (
          <div className="space-y-4">
            {patterns && patterns.length > 0 ? (
              patterns.map((pattern: any) => (
                <Card key={pattern.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base font-medium">{pattern.name}</CardTitle>
                      <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
                        {(pattern.confidence * 100).toFixed(0)}% confidence
                      </span>
                    </div>
                    <CardDescription>{pattern.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{pattern.aiExplanation}</p>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="p-6">
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <AlertTriangle className="h-5 w-5" />
                  <span>No patterns detected</span>
                </div>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;