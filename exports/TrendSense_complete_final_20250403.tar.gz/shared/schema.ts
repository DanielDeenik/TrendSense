import { relations } from 'drizzle-orm';
import { pgTable, serial, text, boolean, timestamp, integer, doublePrecision, jsonb } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

// Fund schema
export const funds = pgTable('funds', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

export const fundsRelations = relations(funds, ({ many }) => ({
  companies: many(companies)
}));

export type Fund = typeof funds.$inferSelect;
export type NewFund = typeof funds.$inferInsert;
export const insertFundSchema = createInsertSchema(funds).omit({ id: true });
export type InsertFund = z.infer<typeof insertFundSchema>;

// Company schema
export const companies = pgTable('companies', {
  id: serial('id').primaryKey(),
  fundId: integer('fund_id').references(() => funds.id).notNull(),
  name: text('name').notNull(),
  sector: text('sector'),
  description: text('description'),
  isPublic: boolean('is_public').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

export const companiesRelations = relations(companies, ({ one, many }) => ({
  fund: one(funds, { fields: [companies.fundId], references: [funds.id] }),
  metrics: many(sustainabilityMetrics),
  documents: many(documents)
}));

export type Company = typeof companies.$inferSelect;
export type NewCompany = typeof companies.$inferInsert;
export const insertCompanySchema = createInsertSchema(companies).omit({ id: true });
export type InsertCompany = z.infer<typeof insertCompanySchema>;

// Sustainability Metrics schema
export const sustainabilityMetrics = pgTable('sustainability_metrics', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id).notNull(),
  name: text('name').notNull(),
  category: text('category').notNull(),
  value: doublePrecision('value').notNull(),
  unit: text('unit').notNull(),
  isAnonymized: boolean('is_anonymized').default(false),
  timestamp: timestamp('timestamp').defaultNow()
});

export const sustainabilityMetricsRelations = relations(sustainabilityMetrics, ({ one }) => ({
  company: one(companies, { fields: [sustainabilityMetrics.companyId], references: [companies.id] })
}));

export type SustainabilityMetric = typeof sustainabilityMetrics.$inferSelect;
export type NewSustainabilityMetric = typeof sustainabilityMetrics.$inferInsert;
export const insertMetricSchema = createInsertSchema(sustainabilityMetrics).omit({ id: true });
export type InsertMetric = z.infer<typeof insertMetricSchema>;

// Pattern schema (for sustainability patterns detected by AI)
export const patterns = pgTable('patterns', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  category: text('category').notNull(),
  detectionMethod: text('detection_method').notNull(),
  confidence: doublePrecision('confidence').notNull(),
  dataPoints: jsonb('data_points').$type<Array<{ company: string; metric: string; value: number }>>(),
  aiExplanation: text('ai_explanation'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

export type Pattern = typeof patterns.$inferSelect;
export type NewPattern = typeof patterns.$inferInsert;
export const insertPatternSchema = createInsertSchema(patterns).omit({ id: true });
export type InsertPattern = z.infer<typeof insertPatternSchema>;

// Document schema (for sustainability reports, ESG disclosures, etc.)
export const documents = pgTable('documents', {
  id: serial('id').primaryKey(),
  companyId: integer('company_id').references(() => companies.id).notNull(),
  title: text('title').notNull(),
  description: text('description'),
  fileUrl: text('file_url'),
  fileType: text('file_type'),
  contentVector: jsonb('content_vector').$type<number[]>(), // For vector search
  uploadedAt: timestamp('uploaded_at').defaultNow()
});

export const documentsRelations = relations(documents, ({ one }) => ({
  company: one(companies, { fields: [documents.companyId], references: [companies.id] })
}));

export type Document = typeof documents.$inferSelect;
export type NewDocument = typeof documents.$inferInsert;
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

// Story schema (AI-generated narrative explaining sustainability patterns)
export const stories = pgTable('stories', {
  id: serial('id').primaryKey(),
  patternId: integer('pattern_id').references(() => patterns.id).notNull(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  visualizationType: text('visualization_type').default('line-chart'),
  visualizationData: jsonb('visualization_data'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

export const storiesRelations = relations(stories, ({ one }) => ({
  pattern: one(patterns, { fields: [stories.patternId], references: [patterns.id] })
}));

export type Story = typeof stories.$inferSelect;
export type NewStory = typeof stories.$inferInsert;
export const insertStorySchema = createInsertSchema(stories).omit({ id: true });
export type InsertStory = z.infer<typeof insertStorySchema>;