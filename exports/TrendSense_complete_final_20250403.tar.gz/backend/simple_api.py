#!/usr/bin/env python3
"""
FastAPI Backend for TrendSense VC Platform
"""
import os
import sys
import json
import logging
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import psycopg2
from psycopg2.extras import RealDictCursor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI
app = FastAPI(title="TrendSense VC API", description="API for TrendSense VC Platform")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For production, specify the actual origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db_config():
    """Get database configuration from environment variables"""
    return {
        "dbname": os.environ.get("PGDATABASE", os.environ.get("DB_NAME", "postgres")),
        "user": os.environ.get("PGUSER", os.environ.get("DB_USER", "postgres")),
        "password": os.environ.get("PGPASSWORD", os.environ.get("DB_PASSWORD", "")),
        "host": os.environ.get("PGHOST", os.environ.get("DB_HOST", "localhost")),
        "port": os.environ.get("PGPORT", os.environ.get("DB_PORT", "5432")),
    }

def get_db_connection():
    """Get a PostgreSQL database connection"""
    # Try to use DATABASE_URL if available
    database_url = os.environ.get("DATABASE_URL")
    if database_url:
        try:
            connection = psycopg2.connect(database_url)
            connection.autocommit = True
            return connection
        except Exception as e:
            logger.error(f"Error connecting to database with DATABASE_URL: {e}")
            # Fall back to individual parameters
    
    # Use individual connection parameters
    try:
        db_config = get_db_config()
        connection = psycopg2.connect(
            dbname=db_config["dbname"],
            user=db_config["user"],
            password=db_config["password"],
            host=db_config["host"],
            port=db_config["port"]
        )
        connection.autocommit = True
        return connection
    except Exception as e:
        logger.error(f"Error connecting to database with individual parameters: {e}")
        # Return dummy connection for development if no database is available
        return None

def ensure_tables_exist():
    """Ensure the necessary tables exist in the database"""
    connection = get_db_connection()
    if not connection:
        logger.error("Could not connect to database to ensure tables exist.")
        return False
    
    try:
        with connection.cursor() as cursor:
            # Check if the tables already exist
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'sustainability_metrics'
                );
            """)
            result = cursor.fetchone()
            tables_exist = result[0] if result else False
            
            if not tables_exist:
                # Create metrics table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS sustainability_metrics (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL,
                        category VARCHAR(50) NOT NULL,
                        value FLOAT NOT NULL,
                        unit VARCHAR(50) NOT NULL,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                # Create funds table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS funds (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL,
                        aum FLOAT,
                        focus VARCHAR(255),
                        year_established INTEGER
                    );
                """)
                
                # Create companies table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS companies (
                        id SERIAL PRIMARY KEY,
                        fund_id INTEGER REFERENCES funds(id),
                        name VARCHAR(255) NOT NULL,
                        sector VARCHAR(255),
                        stage VARCHAR(100),
                        investment_date DATE,
                        investment_amount FLOAT
                    );
                """)
                
                # Create patterns table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS patterns (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL,
                        description TEXT,
                        confidence FLOAT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                logger.info("Successfully created database tables.")
                return True
            
            logger.info("Database tables already exist.")
            return True
    except Exception as e:
        logger.error(f"Error ensuring tables exist: {e}")
        return False
    finally:
        if connection:
            connection.close()

@app.get("/health")
async def health_check():
    """Simple health check endpoint"""
    try:
        # Attempt to connect to the database
        connection = get_db_connection()
        db_status = "connected" if connection else "disconnected"
        if connection:
            connection.close()
            
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "database": db_status
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@app.get("/api/funds")
async def get_funds():
    """Get all funds"""
    try:
        connection = get_db_connection()
        if not connection:
            logger.warning("Database not available, returning sample data")
            # Sample data
            return {
                "funds": [
                    {"id": 1, "name": "Green Future Fund", "aum": 500000000, "focus": "Sustainability", "year_established": 2018},
                    {"id": 2, "name": "Climate Tech Ventures", "aum": 750000000, "focus": "Climate Technology", "year_established": 2015},
                    {"id": 3, "name": "ESG Growth Capital", "aum": 1200000000, "focus": "ESG Leaders", "year_established": 2012}
                ]
            }
        
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("SELECT * FROM funds ORDER BY name")
            funds = cursor.fetchall()
            
            return {"funds": funds}
    except Exception as e:
        logger.error(f"Error fetching funds: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if connection:
            connection.close()

@app.get("/api/companies")
async def get_companies(fund_id: Optional[int] = None):
    """Get all companies, optionally filtered by fund_id"""
    try:
        connection = get_db_connection()
        if not connection:
            logger.warning("Database not available, returning sample data")
            # Sample data
            companies = [
                {"id": 1, "fund_id": 1, "name": "EcoSolutions Ltd", "sector": "Renewable Energy", "stage": "Growth", "investment_date": "2022-03-15", "investment_amount": 12000000},
                {"id": 2, "fund_id": 1, "name": "WaterTech Inc", "sector": "Water Management", "stage": "Series B", "investment_date": "2021-11-22", "investment_amount": 8500000},
                {"id": 3, "fund_id": 2, "name": "Carbon Capture Co", "sector": "Emissions Reduction", "stage": "Series A", "investment_date": "2022-01-10", "investment_amount": 5000000},
                {"id": 4, "fund_id": 2, "name": "Green Transport", "sector": "Electric Vehicles", "stage": "Growth", "investment_date": "2021-08-05", "investment_amount": 15000000},
                {"id": 5, "fund_id": 3, "name": "Sustainable Agriculture", "sector": "AgTech", "stage": "Series C", "investment_date": "2022-02-18", "investment_amount": 22000000}
            ]
            
            if fund_id:
                companies = [c for c in companies if c["fund_id"] == fund_id]
                
            return {"companies": companies}
        
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            if fund_id:
                cursor.execute("SELECT * FROM companies WHERE fund_id = %s ORDER BY name", (fund_id,))
            else:
                cursor.execute("SELECT * FROM companies ORDER BY name")
                
            companies = cursor.fetchall()
            
            return {"companies": companies}
    except Exception as e:
        logger.error(f"Error fetching companies: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if connection:
            connection.close()

@app.get("/api/patterns")
async def get_patterns():
    """Get all patterns"""
    try:
        connection = get_db_connection()
        if not connection:
            logger.warning("Database not available, returning sample data")
            # Sample data
            return {
                "patterns": [
                    {"id": 1, "name": "Renewable Energy Adoption", "description": "Companies adopting renewable energy show 23% higher revenue growth", "confidence": 0.87, "timestamp": "2022-03-10T15:30:00Z"},
                    {"id": 2, "name": "Water Use Efficiency", "description": "Water-efficient companies see 15% lower operational costs", "confidence": 0.79, "timestamp": "2022-02-22T11:45:00Z"},
                    {"id": 3, "name": "Carbon Reduction Leaders", "description": "Top carbon reducers outperform market by 12% annually", "confidence": 0.92, "timestamp": "2022-03-01T09:15:00Z"}
                ]
            }
        
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("SELECT * FROM patterns ORDER BY confidence DESC, name")
            patterns = cursor.fetchall()
            
            return {"patterns": patterns}
    except Exception as e:
        logger.error(f"Error fetching patterns: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if connection:
            connection.close()

@app.get("/api/metrics")
async def get_metrics(company_id: Optional[int] = None):
    """Get all sustainability metrics, optionally filtered by company_id"""
    try:
        connection = get_db_connection()
        if not connection:
            logger.warning("Database not available, returning sample data")
            # Sample metrics data
            metrics = [
                {"id": 1, "name": "Carbon Emissions", "category": "emissions", "value": 12.4, "unit": "tons CO2e", "timestamp": "2022-03-15T12:00:00Z"},
                {"id": 2, "name": "ESG Score", "category": "governance", "value": 73.8, "unit": "points", "timestamp": "2022-03-15T12:00:00Z"},
                {"id": 3, "name": "Renewable Energy", "category": "energy", "value": 38.0, "unit": "%", "timestamp": "2022-03-15T12:00:00Z"},
                {"id": 4, "name": "Water Intensity", "category": "water", "value": 2.3, "unit": "m³/unit", "timestamp": "2022-03-15T12:00:00Z"},
                {"id": 5, "name": "Waste Recycling", "category": "waste", "value": 63.5, "unit": "%", "timestamp": "2022-03-15T12:00:00Z"},
                
                # Historical data for trends
                {"id": 6, "name": "Carbon Emissions", "category": "emissions", "value": 14.7, "unit": "tons CO2e", "timestamp": "2022-02-15T12:00:00Z"},
                {"id": 7, "name": "ESG Score", "category": "governance", "value": 72.1, "unit": "points", "timestamp": "2022-02-15T12:00:00Z"},
                {"id": 8, "name": "Renewable Energy", "category": "energy", "value": 35.2, "unit": "%", "timestamp": "2022-02-15T12:00:00Z"},
                {"id": 9, "name": "Water Intensity", "category": "water", "value": 2.6, "unit": "m³/unit", "timestamp": "2022-02-15T12:00:00Z"},
                {"id": 10, "name": "Waste Recycling", "category": "waste", "value": 61.2, "unit": "%", "timestamp": "2022-02-15T12:00:00Z"}
            ]
            
            return {"metrics": metrics}
        
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            if company_id:
                # In a real application, we would join with a company_metrics table
                cursor.execute("""
                    SELECT * FROM sustainability_metrics
                    WHERE id IN (SELECT metric_id FROM company_metrics WHERE company_id = %s)
                    ORDER BY timestamp DESC, category, name
                """, (company_id,))
            else:
                cursor.execute("SELECT * FROM sustainability_metrics ORDER BY timestamp DESC, category, name")
                
            metrics = cursor.fetchall()
            
            return {"metrics": metrics}
    except Exception as e:
        logger.error(f"Error fetching metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if connection:
            connection.close()

def main():
    """Run the FastAPI server"""
    # Ensure database tables exist
    ensure_tables_exist()
    
    # Get port from environment variable or default to 8000
    port = int(os.environ.get("API_PORT", "8000"))
    
    # Start the server
    logger.info(f"Starting FastAPI server on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port)

if __name__ == "__main__":
    main()