#!/usr/bin/env python3
"""
Seed database with sample sustainability metrics
"""
import os
import sys
import logging
import random
from datetime import datetime, timedelta
import psycopg2
from psycopg2.extras import RealDictCursor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_db_config():
    """Get database configuration from environment variables"""
    return {
        "dbname": os.environ.get("PGDATABASE", os.environ.get("DB_NAME", "postgres")),
        "user": os.environ.get("PGUSER", os.environ.get("DB_USER", "postgres")),
        "password": os.environ.get("PGPASSWORD", os.environ.get("DB_PASSWORD", "")),
        "host": os.environ.get("PGHOST", os.environ.get("DB_HOST", "localhost")),
        "port": os.environ.get("PGPORT", os.environ.get("DB_PORT", "5432")),
    }

def get_db_connection():
    """Get a PostgreSQL database connection"""
    # Try to use DATABASE_URL if available
    database_url = os.environ.get("DATABASE_URL")
    if database_url:
        try:
            connection = psycopg2.connect(database_url)
            connection.autocommit = True
            return connection
        except Exception as e:
            logger.error(f"Error connecting to database with DATABASE_URL: {e}")
            # Fall back to individual parameters
    
    # Use individual connection parameters
    try:
        db_config = get_db_config()
        connection = psycopg2.connect(
            dbname=db_config["dbname"],
            user=db_config["user"],
            password=db_config["password"],
            host=db_config["host"],
            port=db_config["port"]
        )
        connection.autocommit = True
        return connection
    except Exception as e:
        logger.error(f"Error connecting to database with individual parameters: {e}")
        return None

def ensure_tables_exist():
    """Ensure the necessary tables exist in the database"""
    connection = get_db_connection()
    if not connection:
        logger.error("Could not connect to database to ensure tables exist.")
        return False
    
    try:
        with connection.cursor() as cursor:
            # Check if the tables already exist
            cursor.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'sustainability_metrics'
                );
            """)
            result = cursor.fetchone()
            tables_exist = result[0] if result else False
            
            if not tables_exist:
                # Create metrics table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS sustainability_metrics (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL,
                        category VARCHAR(50) NOT NULL,
                        value FLOAT NOT NULL,
                        unit VARCHAR(50) NOT NULL,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                # Create funds table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS funds (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL,
                        aum FLOAT,
                        focus VARCHAR(255),
                        year_established INTEGER
                    );
                """)
                
                # Create companies table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS companies (
                        id SERIAL PRIMARY KEY,
                        fund_id INTEGER REFERENCES funds(id),
                        name VARCHAR(255) NOT NULL,
                        sector VARCHAR(255),
                        stage VARCHAR(100),
                        investment_date DATE,
                        investment_amount FLOAT
                    );
                """)
                
                # Create patterns table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS patterns (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255) NOT NULL,
                        description TEXT,
                        confidence FLOAT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                logger.info("Successfully created database tables.")
                return True
            
            logger.info("Database tables already exist.")
            return True
    except Exception as e:
        logger.error(f"Error ensuring tables exist: {e}")
        return False
    finally:
        if connection:
            connection.close()

def seed_funds():
    """Seed the database with sample funds"""
    connection = get_db_connection()
    if not connection:
        logger.error("Could not connect to database to seed funds.")
        return False
    
    try:
        with connection.cursor() as cursor:
            # Check if funds table already has data
            cursor.execute("SELECT COUNT(*) FROM funds")
            result = cursor.fetchone()
            count = result[0] if result else 0
            
            if count > 0:
                logger.info(f"Funds table already has {count} records, skipping seeding.")
                return True
            
            # Sample funds
            funds_data = [
                {"name": "Green Future Fund", "aum": 500000000, "focus": "Sustainability", "year_established": 2018},
                {"name": "Climate Tech Ventures", "aum": 750000000, "focus": "Climate Technology", "year_established": 2015},
                {"name": "ESG Growth Capital", "aum": 1200000000, "focus": "ESG Leaders", "year_established": 2012},
                {"name": "Renewable Energy Partners", "aum": 350000000, "focus": "Clean Energy", "year_established": 2019},
                {"name": "Sustainable Future VC", "aum": 600000000, "focus": "Sustainable Innovation", "year_established": 2017}
            ]
            
            for fund in funds_data:
                cursor.execute(
                    "INSERT INTO funds (name, aum, focus, year_established) VALUES (%s, %s, %s, %s)",
                    (fund["name"], fund["aum"], fund["focus"], fund["year_established"])
                )
            
            logger.info(f"Successfully seeded {len(funds_data)} funds.")
            return True
    except Exception as e:
        logger.error(f"Error seeding funds: {e}")
        return False
    finally:
        if connection:
            connection.close()

def seed_companies():
    """Seed the database with sample companies"""
    connection = get_db_connection()
    if not connection:
        logger.error("Could not connect to database to seed companies.")
        return False
    
    try:
        with connection.cursor() as cursor:
            # Check if companies table already has data
            cursor.execute("SELECT COUNT(*) FROM companies")
            result = cursor.fetchone()
            count = result[0] if result else 0
            
            if count > 0:
                logger.info(f"Companies table already has {count} records, skipping seeding.")
                return True
            
            # Get fund IDs
            cursor.execute("SELECT id FROM funds")
            fund_ids = [row[0] for row in cursor.fetchall()]
            
            if not fund_ids:
                logger.error("No funds found in the database. Please seed funds first.")
                return False
            
            # Sample companies
            companies_data = [
                {"name": "EcoSolutions Ltd", "sector": "Renewable Energy", "stage": "Growth", "investment_date": "2022-03-15", "investment_amount": 12000000, "fund_id": fund_ids[0] if len(fund_ids) > 0 else None},
                {"name": "WaterTech Inc", "sector": "Water Management", "stage": "Series B", "investment_date": "2021-11-22", "investment_amount": 8500000, "fund_id": fund_ids[0] if len(fund_ids) > 0 else None},
                {"name": "Carbon Capture Co", "sector": "Emissions Reduction", "stage": "Series A", "investment_date": "2022-01-10", "investment_amount": 5000000, "fund_id": fund_ids[1] if len(fund_ids) > 1 else None},
                {"name": "Green Transport", "sector": "Electric Vehicles", "stage": "Growth", "investment_date": "2021-08-05", "investment_amount": 15000000, "fund_id": fund_ids[1] if len(fund_ids) > 1 else None},
                {"name": "Sustainable Agriculture", "sector": "AgTech", "stage": "Series C", "investment_date": "2022-02-18", "investment_amount": 22000000, "fund_id": fund_ids[2] if len(fund_ids) > 2 else None},
                {"name": "CleanTech Innovations", "sector": "Clean Technology", "stage": "Series B", "investment_date": "2021-12-10", "investment_amount": 9500000, "fund_id": fund_ids[2] if len(fund_ids) > 2 else None},
                {"name": "Circular Economy Inc", "sector": "Waste Management", "stage": "Series A", "investment_date": "2022-03-01", "investment_amount": 7000000, "fund_id": fund_ids[3] if len(fund_ids) > 3 else None},
                {"name": "SustainaBuild", "sector": "Green Construction", "stage": "Seed", "investment_date": "2022-02-05", "investment_amount": 2500000, "fund_id": fund_ids[4] if len(fund_ids) > 4 else None}
            ]
            
            for company in companies_data:
                cursor.execute(
                    "INSERT INTO companies (name, sector, stage, investment_date, investment_amount, fund_id) VALUES (%s, %s, %s, %s, %s, %s)",
                    (company["name"], company["sector"], company["stage"], company["investment_date"], company["investment_amount"], company["fund_id"])
                )
            
            logger.info(f"Successfully seeded {len(companies_data)} companies.")
            return True
    except Exception as e:
        logger.error(f"Error seeding companies: {e}")
        return False
    finally:
        if connection:
            connection.close()

def seed_patterns():
    """Seed the database with sample patterns"""
    connection = get_db_connection()
    if not connection:
        logger.error("Could not connect to database to seed patterns.")
        return False
    
    try:
        with connection.cursor() as cursor:
            # Check if patterns table already has data
            cursor.execute("SELECT COUNT(*) FROM patterns")
            result = cursor.fetchone()
            count = result[0] if result else 0
            
            if count > 0:
                logger.info(f"Patterns table already has {count} records, skipping seeding.")
                return True
            
            # Sample patterns
            patterns_data = [
                {"name": "Renewable Energy Adoption", "description": "Companies adopting renewable energy show 23% higher revenue growth", "confidence": 0.87, "timestamp": datetime.now() - timedelta(days=5)},
                {"name": "Water Use Efficiency", "description": "Water-efficient companies see 15% lower operational costs", "confidence": 0.79, "timestamp": datetime.now() - timedelta(days=10)},
                {"name": "Carbon Reduction Leaders", "description": "Top carbon reducers outperform market by 12% annually", "confidence": 0.92, "timestamp": datetime.now() - timedelta(days=7)},
                {"name": "ESG Score Correlation", "description": "Companies with ESG scores >70 have 18% higher investor retention", "confidence": 0.83, "timestamp": datetime.now() - timedelta(days=3)},
                {"name": "Waste Reduction Impact", "description": "Zero-waste initiatives correlated with 8% increase in customer loyalty", "confidence": 0.76, "timestamp": datetime.now() - timedelta(days=8)}
            ]
            
            for pattern in patterns_data:
                cursor.execute(
                    "INSERT INTO patterns (name, description, confidence, timestamp) VALUES (%s, %s, %s, %s)",
                    (pattern["name"], pattern["description"], pattern["confidence"], pattern["timestamp"])
                )
            
            logger.info(f"Successfully seeded {len(patterns_data)} patterns.")
            return True
    except Exception as e:
        logger.error(f"Error seeding patterns: {e}")
        return False
    finally:
        if connection:
            connection.close()

def seed_metrics():
    """Seed the database with sample sustainability metrics"""
    connection = get_db_connection()
    if not connection:
        logger.error("Could not connect to database to seed metrics.")
        return False
    
    try:
        with connection.cursor() as cursor:
            # Check if metrics table already has data
            cursor.execute("SELECT COUNT(*) FROM sustainability_metrics")
            result = cursor.fetchone()
            count = result[0] if result else 0
            
            if count > 0:
                logger.info(f"Metrics table already has {count} records, skipping seeding.")
                return True
            
            # Current metrics data
            current_metrics = [
                {"name": "Carbon Emissions", "category": "emissions", "value": 12.4, "unit": "tons CO2e"},
                {"name": "ESG Score", "category": "governance", "value": 73.8, "unit": "points"},
                {"name": "Renewable Energy", "category": "energy", "value": 38.0, "unit": "%"},
                {"name": "Water Intensity", "category": "water", "value": 2.3, "unit": "m³/unit"},
                {"name": "Waste Recycling", "category": "waste", "value": 63.5, "unit": "%"},
                {"name": "Energy Efficiency", "category": "energy", "value": 84.2, "unit": "%"},
                {"name": "Biodiversity Impact", "category": "environmental", "value": 3.7, "unit": "score"},
                {"name": "Employee Diversity", "category": "social", "value": 68.9, "unit": "%"},
            ]
            
            # Insert current metrics
            current_time = datetime.now()
            for metric in current_metrics:
                cursor.execute(
                    "INSERT INTO sustainability_metrics (name, category, value, unit, timestamp) VALUES (%s, %s, %s, %s, %s)",
                    (metric["name"], metric["category"], metric["value"], metric["unit"], current_time)
                )
            
            # Historical data (past months)
            for month_offset in range(1, 4):  # 3 months of historical data
                historical_time = current_time - timedelta(days=30 * month_offset)
                
                for metric in current_metrics:
                    # Add some random variation to historical values
                    historical_value = metric["value"]
                    
                    # Different logic based on metric category
                    if metric["category"] in ["emissions", "water"]:
                        # For emissions and water, we want to show a decreasing trend (positive)
                        variation = random.uniform(0.02, 0.07)  # 2-7% increase per month going backward
                        historical_value = metric["value"] * (1 + variation * month_offset)
                    elif metric["category"] in ["energy", "governance", "waste", "social"]:
                        # For positive metrics, we want to show an increasing trend
                        variation = random.uniform(0.02, 0.06)  # 2-6% decrease per month going backward
                        historical_value = metric["value"] * (1 - variation * month_offset)
                    else:
                        # Random variation for other metrics
                        variation = random.uniform(-0.05, 0.05)  # -5% to +5%
                        historical_value = metric["value"] * (1 + variation)
                    
                    cursor.execute(
                        "INSERT INTO sustainability_metrics (name, category, value, unit, timestamp) VALUES (%s, %s, %s, %s, %s)",
                        (metric["name"], metric["category"], historical_value, metric["unit"], historical_time)
                    )
            
            logger.info(f"Successfully seeded {len(current_metrics) * 4} metrics (current + 3 months history).")
            return True
    except Exception as e:
        logger.error(f"Error seeding metrics: {e}")
        return False
    finally:
        if connection:
            connection.close()

def main():
    """Main function to seed the database"""
    logger.info("Starting database seeding process...")
    
    # Ensure tables exist
    if not ensure_tables_exist():
        logger.error("Failed to ensure tables exist.")
        sys.exit(1)
    
    # Seed funds
    if not seed_funds():
        logger.error("Failed to seed funds.")
        sys.exit(1)
    
    # Seed companies
    if not seed_companies():
        logger.error("Failed to seed companies.")
        sys.exit(1)
    
    # Seed patterns
    if not seed_patterns():
        logger.error("Failed to seed patterns.")
        sys.exit(1)
    
    # Seed metrics
    if not seed_metrics():
        logger.error("Failed to seed metrics.")
        sys.exit(1)
    
    logger.info("Database seeding completed successfully.")

if __name__ == "__main__":
    main()